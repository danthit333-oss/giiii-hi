"""
Evaluation Script: Machine Learning Model Metrics Extraction & Visualization (Section 4.3 / C3 & C4)
Extracts official metrics from existing Part 1 training and evaluation artifacts:
- part_01_AI_ML/report/xgboost_original/metrics.json
- part_01_AI_ML/report/run_metadata.json
- part_01_AI_ML/report/benchmark_report.txt

Outputs:
- chapter4_evaluation/ml_metrics.json
- chapter4_evaluation/ml_per_class_metrics.csv
- chapter4_evaluation/screenshots/ml_confusion_matrix.png
- chapter4_evaluation/screenshots/ml_per_class_metrics.png
"""

from __future__ import annotations
import csv
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

METRICS_SRC = Path("part_01_AI_ML/report/xgboost_original/metrics.json")
RUN_META_SRC = Path("part_01_AI_ML/report/run_metadata.json")
OUT_JSON = Path("chapter4_evaluation/ml_metrics.json")
OUT_CSV = Path("chapter4_evaluation/ml_per_class_metrics.csv")
CONFUSION_IMG = Path("chapter4_evaluation/screenshots/ml_confusion_matrix.png")
CLASS_METRICS_IMG = Path("chapter4_evaluation/screenshots/ml_per_class_metrics.png")

def main():
    print("[*] Extracting Official Machine Learning Evaluation Artifacts...")
    with open(METRICS_SRC, "r", encoding="utf-8") as f:
        metrics = json.load(f)
    with open(RUN_META_SRC, "r", encoding="utf-8") as f:
        run_meta = json.load(f)

    # Compile unified JSON metrics
    unified = {
        "dataset": run_meta.get("dataset", "CICIoT2023"),
        "model_architecture": "XGBoost Classifier (n_estimators=300, max_depth=10, learning_rate=0.1)",
        "train_file_count": run_meta.get("train_file_count", 135),
        "test_file_count": run_meta.get("test_file_count", 34),
        "total_files": run_meta.get("train_file_count", 135) + run_meta.get("test_file_count", 34),
        "raw_rows_seen_training": sum(run_meta.get("training_rows_seen_by_class", {}).values()),
        "training_rows_after_sampling": run_meta.get("training_rows", 610328),
        "test_rows": metrics.get("test_rows", 9560672),
        "feature_count": run_meta.get("feature_count", 46),
        "accuracy": metrics.get("accuracy", 0.9964106),
        "weighted_f1": metrics.get("weighted_f1", 0.9964384),
        "macro_precision": metrics.get("macro_precision", 0.9134196),
        "macro_recall": metrics.get("macro_recall", 0.9193585),
        "macro_f1": metrics.get("macro_f1", 0.9161388),
        "benign_false_positive_rate": metrics.get("benign_false_positive_rate", 0.061023),
        "bruteforce_f1": metrics.get("per_class", {}).get("BruteForce", {}).get("f1", 0.6943729),
        "prediction_latency_ms_per_row": metrics.get("prediction_ms_per_row", 0.0148576),
        "prediction_total_seconds": metrics.get("prediction_seconds", 142.0488),
        "per_class": metrics.get("per_class", {}),
        "confusion_matrix": metrics.get("confusion_matrix", []),
        "class_order": metrics.get("class_order", [])
    }

    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(unified, f, indent=2, ensure_ascii=False)
    print(f"[+] Saved ML metrics to {OUT_JSON}")

    # Write Per-Class Metrics CSV
    with open(OUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Class", "Precision", "Recall", "F1-Score", "Support"])
        for cname in unified["class_order"]:
            cdata = unified["per_class"].get(cname, {})
            writer.writerow([
                cname,
                f"{cdata.get('precision', 0.0):.4f}",
                f"{cdata.get('recall', 0.0):.4f}",
                f"{cdata.get('f1', 0.0):.4f}",
                cdata.get("support", 0)
            ])
    print(f"[+] Saved per-class metrics to {OUT_CSV}")

    # Generate Confusion Matrix Figure (Without Chapter Number)
    print("[*] Generating Confusion Matrix Visualization...")
    cm = np.array(unified["confusion_matrix"])
    classes = unified["class_order"]
    
    # Calculate row-normalized matrix for percentage display
    cm_norm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    fig, ax = plt.subplots(figsize=(9, 7.5), dpi=300)
    cax = ax.imshow(cm_norm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.colorbar(cax, fraction=0.046, pad=0.04)

    ax.set_xticks(np.arange(len(classes)))
    ax.set_yticks(np.arange(len(classes)))
    ax.set_xticklabels(classes, rotation=45, ha="right", fontsize=10, fontweight="bold")
    ax.set_yticklabels(classes, fontsize=10, fontweight="bold")

    thresh = cm_norm.max() / 2.0
    for i in range(len(classes)):
        for j in range(len(classes)):
            raw_val = f"{cm[i, j]:,}"
            pct_val = f"{cm_norm[i, j]*100:.1f}%"
            text_color = "white" if cm_norm[i, j] > thresh else "black"
            ax.text(j, i, f"{raw_val}\n({pct_val})", ha="center", va="center", color=text_color, fontsize=8)

    ax.set_title("XGBoost 7-Class Confusion Matrix (CICIoT2023 Test Set)", fontsize=13, fontweight="bold", pad=15)
    ax.set_ylabel("True Class", fontsize=11, fontweight="bold")
    ax.set_xlabel("Predicted Class", fontsize=11, fontweight="bold")
    plt.tight_layout()

    CONFUSION_IMG.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(CONFUSION_IMG, dpi=300)
    plt.close()
    print(f"[+] Saved confusion matrix image to {CONFUSION_IMG}")

    # Generate Per-Class Metrics Bar Chart (Without Chapter Number)
    print("[*] Generating Per-Class Metrics Bar Chart...")
    precisions = [unified["per_class"][c]["precision"] * 100 for c in classes]
    recalls = [unified["per_class"][c]["recall"] * 100 for c in classes]
    f1s = [unified["per_class"][c]["f1"] * 100 for c in classes]

    x = np.arange(len(classes))
    width = 0.25

    fig, ax = plt.subplots(figsize=(10, 5.5), dpi=300)
    rects1 = ax.bar(x - width, precisions, width, label='Precision (%)', color='#2b5c8f')
    rects2 = ax.bar(x, recalls, width, label='Recall (%)', color='#419d78')
    rects3 = ax.bar(x + width, f1s, width, label='F1-Score (%)', color='#e07a5f')

    ax.set_ylabel('Percentage (%)', fontsize=11, fontweight="bold")
    ax.set_title('Per-Class Detection Performance Across 7 Network Traffic Categories', fontsize=13, fontweight="bold", pad=15)
    ax.set_xticks(x)
    ax.set_xticklabels(classes, fontsize=10, fontweight="bold")
    ax.legend(loc='lower right', frameon=True)
    ax.set_ylim(0, 115)
    ax.grid(axis='y', linestyle='--', alpha=0.5)

    # Add values on top of bars
    for rects in [rects1, rects2, rects3]:
        for rect in rects:
            height = rect.get_height()
            ax.annotate(f'{height:.1f}',
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=7, rotation=45)

    plt.tight_layout()
    plt.savefig(CLASS_METRICS_IMG, dpi=300)
    plt.close()
    print(f"[+] Saved per-class metrics image to {CLASS_METRICS_IMG}")

if __name__ == "__main__":
    main()
