# THIẾT LẬP MÔI TRƯỜNG VÀ PHƯƠNG PHÁP THỰC NGHIỆM (EXPERIMENTAL SETUP)

Tài liệu này ghi nhận toàn bộ thông số kỹ thuật thực tế của hạ tầng phần cứng, phần mềm, mạng và mô hình máy học phục vụ các bài thực nghiệm trong **Chương 4. Thực nghiệm và đánh giá hệ thống**.

Mọi thông số đều được xác minh trực tiếp trên môi trường runtime (`[RUNTIME VERIFIED]`), tệp cấu hình (`[CONFIG ONLY]`), hoặc mã nguồn hệ thống (`[SOURCE VERIFIED]`).

---

## 1. CẤU HÌNH MÔI TRƯỜNG THỰC NGHIỆM (ENVIRONMENT SPECIFICATIONS)

| Thành phần | Thông số thực tế | Phương pháp xác minh | Trạng thái |
| :--- | :--- | :--- | :--- |
| **Hệ điều hành Host (Host OS)** | Microsoft Windows 11 Pro 64-bit (Version 10.0.26200) | `Get-CimInstance Win32_OperatingSystem` | `[RUNTIME VERIFIED]` |
| **Vi xử lý vật lý (Physical CPU)** | 11th Gen Intel(R) Core(TM) i5-11400H @ 2.70GHz (6 Cores / 12 Threads) | `Get-CimInstance Win32_Processor` | `[RUNTIME VERIFIED]` |
| **RAM vật lý (Physical RAM)** | 32 GB (Khả dụng thực tế 31.74 GB / 34,077,446,144 bytes) | `Get-CimInstance Win32_ComputerSystem` | `[RUNTIME VERIFIED]` |
| **Hạ tầng WSL2** | Phân bổ tài nguyên: `memory=8GB`, `processors=6` tại `~/.wslconfig` | `Get-Content C:\Users\hoang\.wslconfig` | `[RUNTIME VERIFIED]` |
| **WSL2 Kernel & Distro** | Nhân Linux 6.6.x trên bản phân phối `docker-desktop` | `wsl -l -v` | `[RUNTIME VERIFIED]` |
| **Docker Engine** | Phiên bản `29.2.1` (API Version `1.53`, Desktop `4.62.0`) | `docker version` | `[RUNTIME VERIFIED]` |
| **Docker Compose** | Phiên bản `v5.0.2` | `docker compose version` | `[RUNTIME VERIFIED]` |
| **Môi trường Python Host** | Python `3.12.10`, công cụ quản lý gói `uv 0.11.21` | `python --version`, `uv --version` | `[RUNTIME VERIFIED]` |
| **Số lượng Container hoạt động** | 23 containers (21 containers đang chạy ổn định, 2 containers setup hoàn thành `Exited (0)`) | `docker ps -a` | `[RUNTIME VERIFIED]` |
| **Mô hình máy học (ML Model)** | `xgboost_original` (định dạng UBJ `xgboost_original.ubj`, 46 đặc trưng, 7 nhãn phân loại) | `manifest.json`, `metrics.json` | `[RUNTIME VERIFIED]` |
| **Card mạng giám sát (Sensor NIC)** | Wi-Fi: Intel(R) Wi-Fi 6 AX201 160MHz; vEthernet (WSL Hyper-V firewall) 10 Gbps | `Get-NetAdapter` | `[RUNTIME VERIFIED]` |

---

## 2. PHÂN HOẠCH MẠNG DOCKER (DOCKER NETWORK TOPOLOGY)

Hệ thống triển khai chính xác 7 phân vùng mạng độc lập tuân thủ nguyên tắc cô lập phòng thủ chiều sâu (*defense-in-depth*):

| Tên mạng | Trình điều khiển (Driver) | Cách ly nội bộ (Internal) | Mục đích sử dụng |
| :--- | :--- | :--- | :--- |
| `public` | bridge | `false` | Tiếp nhận kết nối mạng ngoài vào Reverse Proxy Edge và HAProxy |
| `lan_ingress` | bridge | `false` | Tiếp nhận lưu lượng mạng LAN mồi đến cổng `0.0.0.0:8080` |
| `lure` | bridge | `true` | Mạng cách ly chứa Web Honeypot (`part2-web`) và SSH Cowrie (`cowrie`) |
| `control` | bridge | `true` | Mạng điều khiển trung tâm kết nối Ingest API, Dashboard, Redis, Prometheus |
| `data` | bridge | `true` | Mạng phân vùng cơ sở dữ liệu nội bộ PostgreSQL (`postgres`) và Redis |
| `siem` | bridge | `true` | Mạng phân tích nhật ký kết nối Elasticsearch, Kibana, Filebeat, Correlation |
| `auth` | bridge | `true` | Mạng định danh xác thực OIDC kết nối Keycloak và cơ sở dữ liệu Keycloak DB |

---

## 3. DANH MỤC CỔNG DỊCH VỤ VÀ ÁNH XẠ (PORT BINDINGS)

| Cổng ánh xạ (Host Port) | Cổng đích Container | Dịch vụ tương ứng | Vai trò và ghi chú |
| :--- | :--- | :--- | :--- |
| `0.0.0.0:8080` | `8080/tcp` | `lan-web-edge` (Nginx ModSecurity) | Cổng mồi Web Honeypot mở ra mạng LAN |
| `127.0.0.1:2222` | `2222/tcp` | `ssh-edge` (HAProxy) | Cổng mồi SSH Honeypot chuyển tiếp tới Cowrie |
| `127.0.0.1:8088` | `8088/tcp` | `edge` (Nginx Control Gateway) | Bảng điều khiển `/dashboard/`, tài liệu API `/api-docs/`, API `/api/` |
| `127.0.0.1:8090` | `8090/tcp` | `edge` (Dedicated Loopback Ingest) | Cổng tiếp nhận log loopback chuyên biệt cho cảm biến nội bộ |
| `0.0.0.0:8180` | `8080/tcp` | `keycloak` | Máy chủ xác thực định danh OIDC / RBAC |
| `127.0.0.1:3000` | `3000/tcp` | `grafana` | Giám sát chỉ số tài nguyên và hiệu năng hệ thống |
| `127.0.0.1:5601` | `4180/tcp` | `kibana-oauth2-proxy` | Phân tích nhật ký chuyên sâu Kibana (xác thực qua OAuth2) |
| `127.0.0.1:9090` | `4180/tcp` | `prometheus-oauth2-proxy` | Thu thập số liệu Prometheus (xác thực qua OAuth2) |
| **Không ánh xạ** | `5432/tcp` | `postgres`, `keycloak-db` | Cô lập hoàn toàn trong mạng `data` và `auth` |
| **Không ánh xạ** | `6379/tcp` | `redis` | Cô lập hoàn toàn trong mạng `control` và `data` |
| **Không ánh xạ** | `9200/tcp` | `elasticsearch` | Cô lập hoàn toàn trong mạng `siem` |

---

## 4. THIẾT KẾ CÁC NHÓM THỰC NGHIỆM ĐÁNH GIÁ (EVALUATION MATRIX)

Hệ thống được kiểm thử thực tế qua 6 nhóm thực nghiệm độc lập:

1. **Nhóm E1 – Phát hiện tấn công Web (Web Attack Detection)**:
   - Đánh giá khả năng bẫy và nhận diện 10 loại hình tấn công Web phổ biến: SQL Injection, Reflected XSS, Stored XSS, Path Traversal, IDOR, RFI, Unrestricted File Upload, Command Injection, XXE, Brute Force.
   - Kiểm tra khả năng chống né tránh (*evasion resistance*) qua biến thể URL encoding, mixed-case, whitespace và cấu trúc lệnh bất thường.

2. **Nhóm E2 – Thu thập và xử lý nhật ký (Logging & Ingestion Pipeline)**:
   - Đánh giá tiếp nhận dữ liệu từ 4 nguồn: Web Honeypot, Cowrie SSH, Suricata IDS, ML Sensor.
   - Kiểm tra cơ chế chống trùng lặp dữ liệu (*deduplication*) dựa trên cặp khóa `(sensor_id, source_event_id)` và tính độc lập với mã băm `event_sha256`.
   - Kiểm thử hành vi phát lại nhật ký (*replay test*) của Web Forwarder khi khởi động lại tiến trình với con trỏ bộ nhớ RAM.

3. **Nhóm E3 – Mô hình máy học phân loại luồng mạng (Machine Learning Evaluation)**:
   - Khai thác bộ số liệu đánh giá chuẩn thức từ tập dữ liệu quy mô lớn CICIoT2023 (hơn 37.1 triệu dòng raw, 9.56 triệu dòng kiểm thử).
   - Đo lường ma trận nhầm lẫn (*confusion matrix*), độ chính xác (*Accuracy*), Macro F1, Weighted F1, hiệu năng từng lớp, tỷ lệ báo động giả (*False Positive Rate*) của lớp Benign và độ chính xác lớp BruteForce.

4. **Nhóm E4 – Phân tích hành vi và tương quan sự kiện (SIEM Correlation Rules)**:
   - Đánh giá 4 quy tắc tương quan: `repeated_login_activity`, `multi_vector_probe`, `upload_then_command`, `high_request_rate`.
   - Thực nghiệm đối chứng âm (*negative controls*): kiểm tra dưới ngưỡng, sai thứ tự tuần tự chuỗi sự kiện (*reversed sequence*), phân tán địa chỉ IP.

5. **Nhóm E5 – Hiệu năng và độ trễ hệ thống (System Performance & Latency)**:
   - Đo độ trễ tiếp nhận API đơn lẻ và thông lượng tiếp nhận theo lô (*batch throughput*).
   - Đo độ trễ suy luận mô hình ML (theo lô và từng dòng riêng lẻ).
   - Đo độ trễ chuyển tiếp Web (chu kỳ thăm dò SQLite Forwarder 2 giây).
   - Đo độ trễ đóng luồng mạng (*flow closure delay* với idle timeout 5s, active timeout 30s).
   - Đo độ trễ hiển thị đầu-cuối (*end-to-end visibility latency*).

6. **Nhóm E6 – Mức độ an toàn và cô lập hệ thống (Safety & Isolation Containment)**:
   - Kiểm thử cô lập thực thi lệnh (*Command Injection containment* - không tạo tiến trình con).
   - Kiểm thử ngăn chặn kết nối hướng ra (*RFI outbound blocking* - không phát sinh kết nối mạng).
   - Kiểm thử cô lập hệ thống tệp (*Path Traversal containment* - không đọc được tệp thật của host/container).
   - Kiểm thử cách ly tệp tải lên (*Upload quarantine* - đổi tên UUID.bin, không cấp quyền thực thi).
   - Kiểm thử cô lập mạng Docker (*Network separation* - container bẫy không kết nối được PostgreSQL, Redis, Elasticsearch).
   - Kiểm tra đặc quyền và tăng cường bảo mật container (*cap_drop: ALL, read_only, no-new-privileges*).
