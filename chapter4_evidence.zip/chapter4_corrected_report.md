# CHƯƠNG 4. THỰC NGHIỆM VÀ ĐÁNH GIÁ HỆ THỐNG (BẢN HIỆU CHỈNH CHUẨN XÁC)

Báo cáo này trình bày toàn bộ kết quả thực nghiệm, kiểm thử tải và đánh giá an toàn cho hệ thống Web Honeypot (*Hệ thống máy chủ bẫy tấn công ứng dụng Web*) kết hợp mạng bẫy Deception (*Mạng bẫy đánh lừa đối phương*), hệ thống phát hiện xâm nhập mạng Suricata NIDS (*Network Intrusion Detection System*), mô hình học máy phân loại luồng XGBoost (*eXtreme Gradient Boosting*) và công cụ tương quan sự kiện SIEM (*Security Information and Event Management*).

Toàn bộ số liệu trong báo cáo được trích xuất trực tiếp từ các phép đo runtime thực tế, nhật ký container, cơ sở dữ liệu PostgreSQL và hồ sơ tạo tác (*artifacts*) đánh giá chính thức của dự án. Mọi chỉ số đều được phân định nguồn gốc minh bạch theo các cấp độ: `[RUNTIME MEASURED]`, `[RUNTIME VERIFIED]`, `[SOURCE VERIFIED]`, `[CONFIG DERIVED]` hoặc `[NOT MEASURED]`.

---

## 4.1. Thiết lập môi trường và phương pháp thực nghiệm

### 4.1.1. Cấu hình môi trường phần cứng và phần mềm

Hệ thống được triển khai trên máy chủ kiểm thử với các thông số kỹ thuật được xác minh trực tiếp:

*   **Hệ điều hành máy chủ vật lý (Host OS):** Microsoft Windows 11 Pro 64-bit (Build 10.0.26200) `[RUNTIME MEASURED]`.
*   **Vi xử lý (CPU):** Intel(R) Core(TM) i5-11400H @ 2.70GHz (6 lõi vật lý / 12 luồng xử lý) `[RUNTIME MEASURED]`.
*   **Bộ nhớ RAM vật lý:** 32.0 GB (Dung lượng khả dụng ghi nhận: 31.74 GB) `[RUNTIME MEASURED]`.
*   **Môi trường ảo hóa WSL2 (Windows Subsystem for Linux 2):** Phân bổ tối đa 8.0 GB RAM và 6 vCPU (theo cấu hình `.wslconfig`), Linux Kernel 6.6.x `[CONFIG DERIVED]`.
*   **Phiên bản Docker Engine & Compose:** Docker Engine 29.2.1, Docker Compose v5.0.2 `[RUNTIME MEASURED]`.
*   **Môi trường Python:** Python 3.12.10 (quản lý môi trường và gói thực thi bằng `uv` v0.11.21) `[RUNTIME MEASURED]`.
*   **Quy mô Container:** Tổng cộng 23 container Docker phục vụ toàn bộ hệ thống (21 container đang vận hành ở trạng thái running/healthy, 2 container `kibana-setup` và `keycloak-setup` đã hoàn tất tác vụ khởi tạo cơ sở dữ liệu ban đầu) `[RUNTIME MEASURED]`.
*   **Phân vùng 7 mạng nội bộ Docker (Docker Networks):**
    1.  `public`: Mạng cầu nối ngoại vi tiếp nhận lưu lượng vào Nginx Edge Proxy.
    2.  `lan_ingress`: Mạng tiếp nhận lưu lượng dành riêng cho bẫy SSH Cowrie.
    3.  `lure`: Mạng bẫy Deception chứa ứng dụng Web Honeypot và Forwarder (gắn cờ `internal: true`, cách ly hoàn toàn với Internet) `[SOURCE VERIFIED]`.
    4.  `control`: Mạng quản trị kết nối Control API, Ingest API và Dashboard (`internal: true`) `[SOURCE VERIFIED]`.
    5.  `data`: Mạng lưu trữ dữ liệu tập trung gồm PostgreSQL và Redis (`internal: true`) `[SOURCE VERIFIED]`.
    6.  `siem`: Mạng phân tích và săn lùng hiểm họa gồm Elasticsearch, Kibana, Filebeat và Correlation Engine (`internal: true`) `[SOURCE VERIFIED]`.
    7.  `auth`: Mạng kiểm soát định danh và xác thực Keycloak (`internal: true`) `[SOURCE VERIFIED]`.
*   **Hạ tầng định danh và xác thực (Identity & Access Management):** Sử dụng hệ thống máy chủ định danh **Keycloak 26.x** (vận hành trên container `keycloak` kết nối cơ sở dữ liệu `keycloak-db`), kết hợp cổng đảo chiều xác thực **oauth2-proxy** bảo vệ truy cập giao diện Kibana và Prometheus `[SOURCE VERIFIED]`.
*   **Các cổng dịch vụ công khai (Published Ports):**
    *   Cổng `8080/tcp` (LAN): Tiếp nhận Web Honeypot từ mạng nội bộ qua `lan-web-edge`.
    *   Cổng `8088/tcp` (Localhost): Tiếp nhận Web Honeypot công khai qua `edge`.
    *   Cổng `8090/tcp` (Localhost): Cổng trung chuyển Control API, Ingest API và Web Dashboard qua `edge`.
    *   Cổng `2222/tcp` (Localhost): Cổng tiếp nhận SSH Honeypot Cowrie qua `ssh-edge`.
    *   Cổng `8180/tcp` (All Interfaces): Giao diện quản trị định danh Keycloak OIDC.
    *   Cổng `3000/tcp` (Localhost): Giao diện giám sát đồ thị Grafana.
    *   Cổng `5601/tcp` (Localhost): Giao diện Kibana SIEM (bảo vệ bởi Keycloak OIDC via oauth2-proxy).
    *   Cổng `9090/tcp` (Localhost): Giao diện Prometheus Metrics (bảo vệ bởi Keycloak OIDC via oauth2-proxy).
    *   Toàn bộ các cổng cơ sở dữ liệu (`Postgres: 5432`, `Redis: 6379`, `Elasticsearch: 9200`) **hoàn toàn không bind ra host** (`PortBindings: null`) `[RUNTIME VERIFIED]`.
*   **Phiên bản mô hình Học máy (Machine Learning Model):** Mô hình phân loại luồng mạng XGBoost phiên bản `xgboost_original.ubj`, cấu hình 46 đặc trưng luồng (features) phân loại 7 nhóm hành vi trên tập dữ liệu chuẩn CICIoT2023 `[SOURCE VERIFIED]`.

---

## 4.2. Đánh giá khả năng thu thập và xử lý dữ liệu

### 4.2.1. Đánh giá Ingestion theo định dạng từng nguồn (API Ingestion by Source-Shaped Payloads)

Thực nghiệm kiểm tra năng lực tiếp nhận, xác thực schema (*Cấu trúc lược đồ dữ liệu*) và ghi nhận của Ingest API đối với 4 định dạng sự kiện từ các nguồn cảm biến khác nhau. Mỗi nguồn thực hiện 25 yêu cầu kiểm thử độc lập:

| Định dạng nguồn dữ liệu (Source Shape) | Số sự kiện sinh ra (Generated) | Forward thành công | Lưu trữ vào DB (Stored) | Trùng lặp (Duplicated) | Lỗi (Failed) | Tỷ lệ tiếp nhận API (Acceptance Rate) | Trạng thái kiểm thử toàn trình (End-to-End Pipeline) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **Web Honeypot** | 25 | 25 | 25 | 0 | 0 | **100.0%** | **Đã xác minh toàn trình qua Replay (276 sự kiện)** `[RUNTIME VERIFIED]` |
| **Cowrie SSH** | 25 | 25 | 25 | 0 | 0 | **100.0%** | Tiếp nhận API đạt 100% `[NOT VERIFIED END-TO-END]` |
| **Suricata NIDS** | 25 | 25 | 25 | 0 | 0 | **100.0%** | Tiếp nhận API đạt 100% `[NOT VERIFIED END-TO-END]` |
| **ML Sensor** | 25 | 25 | 25 | 0 | 0 | **100.0%** | Tiếp nhận API đạt 100% `[NOT VERIFIED END-TO-END]` |
| **Tổng cộng** | **100** | **100** | **100** | **0** | **0** | **100.0%** | **Năng lực tiếp nhận API đạt 100.0%** `[RUNTIME MEASURED]` |

*(Dữ liệu chi tiết tại [ingestion_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ingestion_results.csv) và minh chứng [ingestion_pipeline_results.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ingestion_pipeline_results.png))*

### 4.2.2. Kiểm thử cơ chế loại trừ trùng lặp (Deduplication Mechanism)

Cơ chế Deduplication ngăn chặn hiện tượng nhân bản bản ghi khi mạng truyền thông gặp sự cố khiến trạm cảm biến phải gửi lại dữ liệu:

*   **Kịch bản kiểm thử:** Gửi liên tiếp 6 yêu cầu với cùng cặp khóa định danh `(sensor_id="web-sensor-01", source_event_id="dedup-test-target-001")`:
    *   Lần 1: Gửi payload ban đầu -> Ingest API phản hồi HTTP `201 Created` (`accepted: 1, duplicates: 0`). Cơ sở dữ liệu ghi nhận 1 bản ghi mới `[RUNTIME MEASURED]`.
    *   Lần 2 đến Lần 5: Gửi lại cùng nội dung -> Ingest API phản hồi HTTP `201 Created` (`accepted: 0, duplicates: 1`). Số bản ghi trong PostgreSQL không tăng `[RUNTIME MEASURED]`.
    *   Lần 6: Giữ nguyên cặp `(sensor_id, source_event_id)` nhưng thay đổi toàn bộ nội dung dữ liệu (làm biến đổi mã băm SHA-256 từ `d6dbf436...` thành `1c9ff7ba...`) -> Ingest API vẫn xác định là bản ghi trùng lặp (`duplicates: 1`) và từ chối ghi nhận vào cơ sở dữ liệu `[RUNTIME MEASURED]`.
*   **Kết luận:** Cơ chế Deduplication của hệ thống dựa trên ràng buộc duy nhất (*Unique Constraint*) `uq_sensor_source_event` của cặp `(sensor_id, source_event_id)` tại mức cơ sở dữ liệu PostgreSQL, hoàn toàn không phụ thuộc vào `event_sha256` `[SOURCE VERIFIED]`.

### 4.2.3. Kiểm thử Replay của Web Forwarder khi khởi động lại (Forwarder Replay Test)

*   **Quy trình thực nghiệm:**
    1. Kiểm tra hàng đợi SQLite cục bộ tại container `part2-web` (đang lưu 276 sự kiện) và số lượng bản ghi hiện tại trong bảng `events` của PostgreSQL (301 bản ghi).
    2. Khởi động lại container `part2-forwarder-1` (`docker restart part2-forwarder-1`).
    3. Do con trỏ đọc (*cursor tracking*) của forwarder được duy trì trên bộ nhớ RAM, khi tiến trình khởi động lại, con trỏ được reset về đầu và quét lại toàn bộ 276 sự kiện từ SQLite gửi sang Ingest API.
    4. Toàn bộ 276 sự kiện gửi lại đều bị cơ chế Deduplication tại API/DB từ chối lưu mới (`accepted: 0, duplicates: 276`). Tổng số bản ghi trong bảng `events` của PostgreSQL giữ nguyên chính xác 301 bản ghi `[RUNTIME VERIFIED]`.
*   **Đánh giá:** Kiến trúc Local-First (*Ghi nhật ký cục bộ trước khi đẩy qua mạng*) bảo toàn các sự kiện trong hàng đợi SQLite cục bộ khi forwarder khởi động lại, và cơ chế dedup tại cơ sở dữ liệu ngăn chặn việc nhân bản bản ghi `[RUNTIME VERIFIED]`.

---

## 4.3. Đánh giá khả năng phát hiện tấn công

### 4.3.1. Đánh giá Web Honeypot Detection (10 danh mục tấn công Web)

Hệ thống Web Honeypot được kiểm thử với 10 danh mục tấn công Web phổ biến. Mỗi danh mục được kiểm thử bằng 5 mẫu tải độc hại (*payloads*) độc lập:

| Lớp tấn công (Attack Category) | Số test | Phát hiện | Bỏ sót | Tỷ lệ phát hiện | Lỗ hổng kỳ vọng | Lỗ hổng thực tế ghi nhận |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **SQL Injection** | 5 | 5 | 0 | **100.0%** | sqli | sqli |
| **Reflected XSS** | 5 | 5 | 0 | **100.0%** | xss | xss |
| **Stored XSS** | 5 | 5 | 0 | **100.0%** | xss | xss |
| **Path Traversal** | 5 | 5 | 0 | **100.0%** | path_traversal | path_traversal |
| **IDOR** | 5 | 5 | 0 | **100.0%** | idor | idor |
| **RFI (Remote File Inclusion)** | 5 | 5 | 0 | **100.0%** | rfi | rfi |
| **Unrestricted File Upload** | 5 | 5 | 0 | **100.0%** | file_upload | file_upload |
| **Command Injection** | 5 | 5 | 0 | **100.0%** | command_injection | command_injection |
| **XXE (XML External Entity)** | 5 | 5 | 0 | **100.0%** | xxe | xxe |
| **Brute Force (Login)** | 5 | 5 | 0 | **100.0%** | brute_force | brute_force |
| **Tổng cộng** | **50** | **50** | **0** | **100.0%** | - | - |

`[RUNTIME MEASURED]` — Trích xuất từ [web_detection_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/web_detection_results.csv) và minh chứng [web_detection_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/web_detection_matrix.png).

#### Đánh giá tính vững chắc trước kỹ thuật né tránh (Obfuscation & Evasion Testing)
Khi kiểm thử bổ sung với 8 mẫu tải độc hại áp dụng kỹ thuật làm mờ (*obfuscation*):
*   *URL Double Encoding SQLi* (`%2527%2520OR...`): **Bị bỏ sót (False Negative)** do regex chỉ quét chuỗi sau 1 lần giải mã URL chuẩn.
*   *Hex-encoded Stored XSS* (`<script>\x61\x6c...`): **Phát hiện thành công** (khớp thẻ `<script>`).
*   *Unicode/Overlong UTF-8 Path Traversal* (`%c0%ae%c0%ae/`): **Bị bỏ sót** do regex chỉ kiểm tra chuỗi ASCII `../` và `..\\`.
*   *Command Injection chèn biến môi trường* (`cat$IFS/etc/passwd`): **Phát hiện thành công** (khớp chuỗi `/etc/passwd`).
*   *SQLi dùng Inline Comment* (`UN/**/ION/**/SEL/**/ECT`): **Bị bỏ sót** do regex tĩnh yêu cầu khoảng trắng phân tách.
*   *Command Injection nối chuỗi* (`c'a't /etc/passwd`): **Phát hiện thành công**.
*   *XSS dùng SVG onload* (`<svg/onload=alert(1)>`): **Phát hiện thành công**.
*   *UTF-16 encoded XXE*: **Bị bỏ sót** do parser xử lý luồng byte không khớp regex ASCII.

*Kết luận:* Bộ phân tích Web Honeypot đạt tỷ lệ phát hiện 100% đối với các mẫu tấn công tiêu chuẩn, nhưng bộc lộ tỷ lệ bỏ sót 50% (4/8 mẫu) trước các kỹ thuật làm mờ nâng cao (double encoding, inline comments, overlong UTF-8).

### 4.3.2. Đánh giá chữ ký luật Suricata NIDS (Signature-based Detection)

Kiểm thử 10 chữ ký định danh luật (SID) trong tệp quy tắc chính thức `part_05_IDS_ML_DETECTION/config/suricata/honeypot.rules`:

| SID | Tên quy tắc trong `honeypot.rules` | Lỗ hổng ánh xạ | Số test | Cảnh báo đúng | Bỏ sót (FN) | Tỷ lệ phát hiện |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| **9900001** | HONEYPOT possible SQL injection | `sql_injection` | 5 | 4 | 1 | **80.0%** |
| **9900002** | HONEYPOT reflected XSS payload | `reflected_xss` | 5 | 5 | 0 | **100.0%** |
| **9900003** | HONEYPOT path traversal | `path_traversal` | 5 | 5 | 0 | **100.0%** |
| **9900004** | HONEYPOT command injection | `command_injection` | 5 | 5 | 0 | **100.0%** |
| **9900005** | HONEYPOT XXE payload | `xxe` | 5 | 5 | 0 | **100.0%** |
| **9900006** | HONEYPOT remote include attempt | `remote_file_inclusion` | 5 | 5 | 0 | **100.0%** |
| **9900007** | HONEYPOT executable upload name | `unrestricted_file_upload` | 5 | 5 | 0 | **100.0%** |
| **9900008** | HONEYPOT repeated login requests | `brute_force` | 1 | 1 | 0 | **100.0%** |
| **9900009** | HONEYPOT restricted record IDOR | `idor` | 5 | 5 | 0 | **100.0%** |
| **9900010** | HONEYPOT stored XSS submission | `stored_xss` | 5 | 5 | 0 | **100.0%** |
| **Control** | Benign Normal Traffic (Lưu lượng sạch) | `none` | 3 | 0 | 0 | **0.0% FP** |

`[RUNTIME MEASURED]` — Trích xuất từ [signature_detection_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/signature_detection_results.csv) và minh chứng [suricata_signatures_detection.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/suricata_signatures_detection.png).

*Ghi chú về SID 9900001:* Mẫu `/ho-so?id='or'1'='1` không kích hoạt cảnh báo do biểu thức PCRE quy định bắt buộc phải có khoảng trắng `\s+` sau từ khóa `or`. Các mẫu có khoảng trắng chuẩn đạt tỷ lệ phát hiện 100%.

### 4.3.3. Đánh giá mô hình học máy (Machine Learning Evaluation)

Số liệu đánh giá mô hình phân loại luồng XGBoost trích xuất từ hồ sơ tạo tác chính thức `part_01_AI_ML/report/xgboost_original/metrics.json` và `part_01_AI_ML/report/run_metadata.json`:

*   **Tập dữ liệu:** **CICIoT2023** `[SOURCE VERIFIED]`.
*   **Tổng số tệp dữ liệu:** 169 tệp (135 tệp huấn luyện, 34 tệp kiểm thử độc lập) `[SOURCE VERIFIED]`.
*   **Số dòng luồng thô đã thấy trong tập train:** **37,101,078 dòng** `[SOURCE VERIFIED]`.
*   **Số mẫu train sau lấy mẫu cân bằng (reservoir sampling):** **610,328 mẫu** `[SOURCE VERIFIED]`.
*   **Số mẫu kiểm thử độc lập:** **9,560,672 mẫu** `[SOURCE VERIFIED]`.
*   **Số lượng đặc trưng trích xuất:** **46 đặc trưng luồng** `[SOURCE VERIFIED]`.

#### Chỉ số tổng quát trên 9,560,672 mẫu kiểm thử:
*   **Độ chính xác toàn cục (Accuracy):** **99.64%** (0.996411) `[SOURCE VERIFIED]`.
*   **Độ F1 có trọng số (Weighted F1):** **99.64%** (0.996438) `[SOURCE VERIFIED]`.
*   **Macro Precision:** **91.34%** (0.913420) `[SOURCE VERIFIED]`.
*   **Macro Recall:** **91.94%** (0.919358) `[SOURCE VERIFIED]`.
*   **Macro F1-Score:** **91.61%** (0.916139) `[SOURCE VERIFIED]`.
*   **Tỷ lệ dương tính giả lớp lành tính (Benign FPR):** **6.10%** (0.061023) `[SOURCE VERIFIED]`.

#### Bảng chỉ số chi tiết theo 7 phân lớp của tập CICIoT2023:
| Phân lớp (Class) | Precision | Recall | F1-Score | Số mẫu kiểm thử (Support) |
| :--- | :---: | :---: | :---: | :---: |
| **Benign (Lành tính)** | 96.02% | 93.90% | **94.95%** | 224,718 |
| **DDoS (Từ chối dịch vụ phân tán)** | 100.00% | 99.96% | **99.98%** | 6,963,377 |
| **DoS (Từ chối dịch vụ)** | 99.90% | 99.98% | **99.94%** | 1,658,599 |
| **Recon (Rà quét trinh sát)** | 83.50% | 90.97% | **87.07%** | 72,191 |
| **BruteForce (Dò quét mật khẩu)** | 69.87% | 69.01% | **69.44%** | 2,736 |
| **Spoofing (Giả mạo địa chỉ)** | 90.14% | 89.74% | **89.94%** | 99,248 |
| **Mirai (Mã độc IoT)** | 99.98% | 99.99% | **99.98%** | 539,803 |

`[SOURCE VERIFIED]` — Chi tiết xem [ml_metrics.json](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ml_metrics.json), [ml_per_class_metrics.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ml_per_class_metrics.csv), minh chứng [ml_confusion_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ml_confusion_matrix.png) và [ml_per_class_metrics.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ml_per_class_metrics.png).

*Nhận xét:* Lớp **BruteForce** đạt chỉ số F1 khiêm tốn nhất (**69.44%**) do lưu lượng mạng của hành vi dò quét mật khẩu có kích thước và khoảng cách thời gian gói tin rất gần với lưu lượng đăng nhập sai thông thường. Điểm yếu này được bù đắp bởi quy tắc tương quan mức ứng dụng `repeated_login_activity` của SIEM.

---

## 4.4. Đánh giá phân tích hành vi và tương quan sự kiện (SIEM Correlation)

Công cụ tương quan sự kiện (`part_06_SIEM_ALERTING/siem/correlation.py`) được kiểm thử với 4 quy tắc tương quan và các kịch bản đối chứng âm (*Negative Controls*):

### 4.4.1. Kết quả kiểm thử các quy tắc tương quan

| Mã quy tắc (Rule ID) | Kịch bản kiểm thử | Kết quả kỳ vọng | Kết quả thực tế | Trạng thái | Chứng cứ (Evidence) | Thời gian hàm Python | Độ trễ dịch vụ thực tế |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **repeated_login_activity** | >=5 lần truy cập `/auth/login` trong 60s | TRIGGER | TRIGGER | **PASS** | 5 sự kiện | 0.042 s `[MEASURED]` | 30s loop `[CONFIG DERIVED]` |
| *repeated_login_negative* | Chỉ 4 lần truy cập `/auth/login` | NO_TRIGGER | NO_TRIGGER | **PASS** | 0 sự kiện | 0.038 s `[MEASURED]` | N/A |
| **multi_vector_probe** | >=3 lỗ hổng khác nhau trong 600s | TRIGGER | TRIGGER | **PASS** | 3 sự kiện | 0.045 s `[MEASURED]` | 30s loop `[CONFIG DERIVED]` |
| *multi_vector_negative* | Chỉ 2 lỗ hổng khác nhau | NO_TRIGGER | NO_TRIGGER | **PASS** | 0 sự kiện | 0.039 s `[MEASURED]` | N/A |
| **upload_then_command** | Tải tệp lên -> Tiêm lệnh OS trong 900s | TRIGGER | TRIGGER | **PASS** | 2 sự kiện | 0.043 s `[MEASURED]` | 30s loop `[CONFIG DERIVED]` |
| *upload_then_cmd_reversed* | **Tiêm lệnh trước -> Tải tệp sau (Sai thứ tự)** | **NO_TRIGGER** | **NO_TRIGGER** | **PASS** | 0 sự kiện | 0.041 s `[MEASURED]` | N/A |
| **high_request_rate** | >=50 yêu cầu HTTP trong 60s | TRIGGER | TRIGGER | **PASS** | 50 sự kiện | 0.058 s `[MEASURED]` | 30s loop `[CONFIG DERIVED]` |
| *high_request_negative* | Chỉ 49 yêu cầu HTTP | NO_TRIGGER | NO_TRIGGER | **PASS** | 0 sự kiện | 0.049 s `[MEASURED]` | N/A |

`[RUNTIME MEASURED & CONFIG DERIVED]` — Trích xuất từ [correlation_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/correlation_results.csv) và minh chứng [correlation_rules_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/correlation_rules_matrix.png).

### 4.4.2. Minh chứng lưu trữ cảnh báo tương quan trong bảng `events` của PostgreSQL

Cảnh báo tương quan được đẩy từ tiến trình `siem/run.py` qua Ingest API và ghi nhận trực tiếp vào bảng **`events`** của PostgreSQL:
*   **Sensor ID:** `siem-correlation-01` `[SOURCE VERIFIED]`.
*   **Loại sự kiện (event_type):** `alert` `[SOURCE VERIFIED]`.
*   **Phương thức (method):** `CORRELATE` `[SOURCE VERIFIED]`.
*   **Đường dẫn (path):** `siem://correlation` `[SOURCE VERIFIED]`.
*   **Trường `vulnerability`:** Lưu mã định danh quy tắc tương quan (ví dụ: `upload_then_command`, `high_request_rate`).
*   **Trường `request_metadata`:** Lưu trữ đối tượng JSON chứa tiêu đề và mảng các UUID của sự kiện nguồn: `{"title": "...", "evidence_ids": ["...", "..."]}` `[RUNTIME VERIFIED]`.

*(Minh chứng truy vấn SQL thực tế tại [correlation_alert_postgres_evidence.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/correlation_alert_postgres_evidence.png))*

### 4.4.3. Các đặc tính kiến trúc cần lưu ý của bộ tương quan
1.  **Chu kỳ quét (Polling Interval):** Tiến trình ngủ cứng 30 giây (`time.sleep(30)`) giữa các chu kỳ quét `[SOURCE VERIFIED]`.
2.  **Giới hạn cửa sổ dữ liệu:** Mỗi chu kỳ chỉ truy vấn 200 sự kiện gần nhất (`LIMIT 200`), sự kiện vượt quá ngưỡng trong chu kỳ có nguy cơ bị trôi `[SOURCE VERIFIED]`.
3.  **Con trỏ bộ nhớ:** Tiến trình không lưu con trỏ trạng thái bền vững (*Persistent Watermark*) xuống đĩa `[SOURCE VERIFIED]`.
4.  **Thiếu cơ chế ức chế cảnh báo lặp (Suppression / Cooldown):** Khi một cuộc tấn công kéo dài, cảnh báo tương tự tiếp tục được sinh lặp lại ở mỗi chu kỳ 30 giây khi các sự kiện cũ vẫn còn nằm trong cửa sổ thời gian trượt `[SOURCE VERIFIED]`.
5.  **Gom nhóm theo IP:** Thuật toán gom nhóm bằng `source_ip`, có thể gây nhầm lẫn nếu nhiều người dùng đứng sau cùng mạng NAT hoặc Proxy chia sẻ IP `[SOURCE VERIFIED]`.

---

## 4.5. Đánh giá hiệu năng và độ trễ hệ thống

### 4.5.1. Độ trễ tiếp nhận Ingest API (Ingestion Latency Benchmark)

Kiểm thử với 500 yêu cầu độc lập gửi qua Nginx Edge Proxy vào Ingest API (áp dụng nhịp độ điều phối pacing ~90ms để kiểm tra khả năng xử lý đơn lẻ trong ngưỡng cấu hình giới hạn tốc độ `limit_req 10r/s burst=30`):

| Chỉ số hiệu năng (Metric) | Giá trị đo lường | Nhãn phân định nguồn gốc |
| :--- | :---: | :---: |
| **Số lượng mẫu đo (N)** | **500 yêu cầu** | `[RUNTIME MEASURED]` |
| **Độ trễ trung bình (Mean Latency)** | **24.67 ms** | `[RUNTIME MEASURED]` |
| **Độ trễ trung vị (Median / P50)** | **22.16 ms** | `[RUNTIME MEASURED]` |
| **Phân vị 95 (P95 Latency)** | **38.16 ms** | `[RUNTIME MEASURED]` |
| **Phân vị 99 (P99 Latency)** | **42.32 ms** | `[RUNTIME MEASURED]` |
| **Độ trễ nhỏ nhất (Min)** | **13.99 ms** | `[RUNTIME MEASURED]` |
| **Độ trễ lớn nhất (Max)** | **57.26 ms** | `[RUNTIME MEASURED]` |
| **Thông lượng nạp theo lô (Batch Throughput)** | **156.31 sự kiện/giây** | `[RUNTIME MEASURED]` (Lô 50 sự kiện) |

*(Minh chứng biểu đồ phân phối tại [api_ingestion_latency_distribution.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/api_ingestion_latency_distribution.png))*

### 4.5.2. Độ trễ suy luận mô hình học máy (ML Inference Latency)

*   **Chế độ nạp lô (Batch Inference - 10,000 dòng luồng):** Tổng thời gian 91.90 ms -> **0.00919 ms / dòng luồng** (Tương đương hơn 108,000 luồng/giây trên CPU) `[RUNTIME MEASURED]`.
*   **Chế độ đơn vị thời gian thực (Single Row Realtime Inference):**
    *   Trung bình: **2.99 ms / luồng** `[RUNTIME MEASURED]`.
    *   Phân vị 95 (P95): **4.38 ms / luồng** `[RUNTIME MEASURED]`.

### 4.5.3. Bảng phân rã độ trễ các phân đoạn kiến trúc

| Phân đoạn kiến trúc (Architectural Stage) | Giá trị đo lường / Cấu hình | Cấp độ xác minh nguồn gốc | Cơ chế chi phối |
| :--- | :---: | :---: | :--- |
| **1. Web Request -> Ghi SQLite cục bộ** | **[NOT MEASURED]** | `[NOT MEASURED]` | Ghi tệp SQLite cục bộ trong cùng container |
| **2. SQLite -> Ingest API (Forwarder Delay)** | **2.0 giây** | `[CONFIG DERIVED]` | Chu kỳ thăm dò `POLL_INTERVAL = 2.0` |
| **3. Đóng luồng mạng (Flow Closure Timeout)** | **5.0s - 30.0s** | `[CONFIG DERIVED]` | Cấu hình `idle_timeout=5.0s`, `active_timeout=30.0s` |
| **4. Thời gian hàm tương quan (`correlate()`)** | **0.038s - 0.058s** | `[RUNTIME MEASURED]` | Thời gian thực thi thuật toán so khớp Python |
| **5. Chu kỳ quét tương quan nền** | **30.0 giây** | `[CONFIG DERIVED]` | Vòng lặp ngủ `time.sleep(30)` của daemon SIEM |
| **6. Kéo dữ liệu sự kiện trên Dashboard** | **3.0 giây** | `[CONFIG DERIVED]` | Chu kỳ Polling HTTP GET của React Frontend |
| **7. Cập nhật chỉ số thống kê tổng hợp (KPI)** | **30.0 giây** | `[CONFIG DERIVED]` | Thời gian sống đệm `TTL = 30.0s` của Redis |
| **8. Tấn công -> Hiển thị trên Dashboard** | **[NOT MEASURED]** | `[NOT MEASURED]` | Chưa đo tự động toàn trình qua đồng hồ trình duyệt |

*(Minh chứng biểu đồ phân rã tại [latency_component_breakdown.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/latency_component_breakdown.png))*

---

## 4.6. Đánh giá mức độ an toàn và khả năng cô lập hệ thống

| Mã test | Thành phần kiểm thử | Hành vi kỳ vọng | Hành vi thực tế ghi nhận | Kết quả | Bằng chứng thực nghiệm |
| :--- | :--- | :--- | :--- | :---: | :--- |
| **F1** | **Command Injection** | Không sinh tiến trình OS thật | Giao diện trả kết quả giả lập (`uid=33(www-data)`), không có tiến trình OS nào được sinh ra | **PASS** | Danh sách tiến trình `ps aux` trong container trước và sau khi gửi payload hoàn toàn không thay đổi `[RUNTIME VERIFIED]` |
| **F2** | **Remote File Inclusion (RFI)** | Không phát sinh kết nối ra ngoài | Trả về nội dung bẫy tĩnh; máy chủ HTTP listener kiểm thử nhận 0 request | **PASS** | Socket listener tại máy kiểm tra nhận 0 kết nối từ Web Honeypot `[RUNTIME VERIFIED]` |
| **F3** | **Path Traversal** | Không đọc được tệp thật | Tạo tệp canary `/tmp/canary_secret_flag.txt`; gửi payload traversal -> nhận phản hồi giả lập, tệp thật an toàn | **PASS** | Phản hồi HTTP không chứa chuỗi canary bí mật `[RUNTIME VERIFIED]` |
| **F4** | **XML External Entity (XXE)** | Trình phân tích XML không gọi thực thể ngoài | Không thực thi phân giải DTD ngoài, không đọc tệp hệ thống, listener nhận 0 kết nối | **PASS** | HTTP listener nhận 0 yêu cầu kết nối từ parser XML `[RUNTIME VERIFIED]` |
| **F5** | **File Upload Containment** | Cô lập tệp tải lên, không thể thực thi mã | Tệp mã độc được đổi tên UUID dạng `.bin`, chuyển vào thư mục cách ly `quarantine/`, route web trả 404 | **PASS** | Tệp lưu dạng `quarantine/<uuid>.bin`, vô hiệu hóa quyền thực thi, truy cập trực tiếp qua HTTP bị chặn `[RUNTIME VERIFIED]` |
| **F6-Postgres** | **Network Isolation (DB)** | Bẫy Web không thể truy cập cổng 5432 | Kết nối từ container `part2-web` sang PostgreSQL báo lỗi `Network is unreachable` | **PASS** | Container bẫy nằm ở mạng `lure`, PostgreSQL nằm ở mạng `data` (không có cầu nối) `[RUNTIME VERIFIED]` |
| **F6-Redis** | **Network Isolation (Cache)**| Bẫy Web không thể truy cập cổng 6379 | Kết nối từ container `part2-web` sang Redis báo lỗi `Network is unreachable` | **PASS** | Mạng `lure` và mạng `data` bị cô lập hoàn toàn `[RUNTIME VERIFIED]` |
| **F6-Elastic** | **Network Isolation (SIEM)** | Bẫy Web không thể truy cập cổng 9200 | Kết nối từ container `part2-web` sang Elasticsearch báo lỗi `Network is unreachable` | **PASS** | Mạng `lure` và mạng `siem` bị cô lập hoàn toàn `[RUNTIME VERIFIED]` |
| **F7** | **Host Port Exposure** | Cổng dữ liệu không lộ ra ngoài host | Docker inspect xác nhận `PortBindings: null` cho các cổng 5432, 6379, 9200 | **PASS** | Toàn bộ cơ sở dữ liệu chỉ lắng nghe trong mạng nội bộ ảo Docker `[RUNTIME VERIFIED]` |
| **F8** | **Container Hardening** | Thu hồi quyền hạt nhân tối đa | Cấu hình Docker Compose thiết lập `cap_drop: [ALL]`, `no-new-privileges: true`, không gắn Docker Socket | **PASS** | Container không thể leo thang đặc quyền nhân `[CONFIG & RUNTIME VERIFIED]` |

*(Minh chứng tại [isolation_containment_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/isolation_containment_matrix.png) và [upload_quarantine_storage.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/upload_quarantine_storage.png))*

---

## 4.7. Phân tích ưu điểm, hạn chế và khả năng phát triển

### 4.7.1. Các ưu điểm đã được chứng minh qua thực nghiệm
1.  **Độ tin cậy ghi nhật ký cục bộ:** Mô hình SQLite đệm tại trạm bẫy giúp bảo toàn các sự kiện trong hàng đợi khi forwarder khởi động lại, và cơ chế dedup tại cơ sở dữ liệu ngăn chặn nhân bản bản ghi `[RUNTIME VERIFIED]`.
2.  **Cơ chế Deduplication mức cơ sở dữ liệu:** Ràng buộc `(sensor_id, source_event_id)` ngăn chặn việc nhân bản sự kiện khi có yêu cầu gửi lại `[RUNTIME MEASURED]`.
3.  **Giả lập an toàn:** Phản hồi các lỗ hổng nguy hiểm (RCE, RFI, XXE, Traversal) bằng nội dung bẫy tĩnh mà không khởi tạo tiến trình hệ thống thật hay phát sinh kết nối độc hại ra ngoài `[RUNTIME VERIFIED]`.
4.  **Phân vùng mạng nghiêm ngặt:** Mô hình phân vùng mạng với 5 mạng nội bộ cô lập đảm bảo container bẫy bị xâm nhập không thể kết nối tới cơ sở dữ liệu hay hệ thống quản trị `[RUNTIME VERIFIED]`.
5.  **Hiệu năng tiếp nhận API cao:** Ingest API có độ trễ trung bình 24.67 ms (P95 đạt 38.16 ms), đáp ứng thông lượng 156 sự kiện/giây ở chế độ lô `[RUNTIME MEASURED]`.
6.  **Kết hợp giữa Chữ ký luật và Học máy:** Suricata phát hiện nhanh các mẫu đã biết với độ chính xác cao; mô hình XGBoost đạt Accuracy 99.64% và tốc độ suy luận nhanh (0.009 ms/luồng) trên tập kiểm thử 9.56 triệu mẫu CICIoT2023 `[SOURCE VERIFIED]`.

### 4.7.2. Bảng phân tích hạn chế thực tế và giải pháp phát triển

| Hạn chế kỹ thuật (Limitation) | Bằng chứng thực nghiệm (Evidence) | Tác động hệ thống (Impact) | Hướng cải tiến đề xuất (Possible Improvement) |
| :--- | :--- | :--- | :--- |
| **Web detection dựa nhiều vào regex tĩnh** | Bỏ sót 4/8 mẫu payload làm mờ (Double encoding, inline comments) | Bỏ lọt các kỹ thuật né tránh tinh vi của hacker có kỹ năng | Tích hợp bộ giải mã chuẩn hóa nâng cao (WAF Normalizer) hoặc thư viện Libinjection |
| **Nguy cơ Fingerprinting bẫy Web** | Các phản hồi giả lập có nội dung cố định (static mock responses) | Kẻ tấn công có thể nhận diện môi trường Honeypot qua độ trễ và nội dung không đổi | Động hóa dữ liệu phản hồi, ngẫu nhiên hóa token và nội dung mô phỏng theo từng phiên |
| **Con trỏ Forwarder lưu trên RAM** | Khi restart container `part2-forwarder-1`, toàn bộ 276 sự kiện cũ được đọc lại từ đầu | Tăng tải vô ích cho mạng và Ingest API khi container khởi động lại | Lưu con trỏ trạng thái (cursor state offset) vào tệp bền vững trên ổ đĩa |
| **Độ trễ đóng luồng mạng của ML Sensor** | Cấu hình cảm biến yêu cầu `idle_timeout=5s`, `active_timeout=30s` | Dự báo tấn công bằng ML có độ trễ tối thiểu từ 5 đến 30 giây sau khi gói tin truyền qua | Áp dụng mô hình dự báo sớm sau N gói tin đầu tiên (Early traffic classification) |
| **Phân lớp BruteForce của ML còn yếu** | F1-Score chỉ đạt 69.44% (Recall 69.01%) trên tập 2,736 mẫu kiểm thử | Bỏ sót các đợt rà quét mật khẩu nếu chỉ dựa thuần túy vào phân tích luồng mạng ML | Bổ sung các đặc trưng tần suất gói tin và thời gian gõ phím; phụ thuộc vào SIEM Correlation |
| **Chu kỳ quét tương quan cố định 30s** | Vòng lặp `siem/run.py` thực hiện `sleep(30)` | Cảnh báo tương quan có độ trễ lớn | Chuyển sang kiến trúc xử lý luồng sự kiện thời gian thực (Stream processing qua Kafka/Flink) |
| **Cửa sổ tương quan giới hạn 200 sự kiện** | Câu truy vấn SQL cố định `LIMIT 200` | Khi có bão sự kiện, các sự kiện vượt ngưỡng 200 sẽ bị trôi và bỏ sót tương quan | Sử dụng con trỏ thời gian (watermark) và phân mảnh xử lý theo khối thời gian (micro-batching) |
| **Thiếu cơ chế ức chế cảnh báo lặp (Suppression)** | Kịch bản tương quan sinh lặp lại alert ở mỗi chu kỳ quét khi sự kiện còn trong time window | Gây ngập lụt bảng cảnh báo (alert fatigue) cho chuyên viên phân tích SOC | Thêm cơ chế ghi nhận trạng thái cảnh báo và thời gian tạm lắng (cooldown suppression period) |
| **Gom nhóm theo IP dễ nhầm lẫn mạng NAT** | Thuật toán gom nhóm chủ yếu bằng `GROUP BY source_ip` | Nhiều người dùng đứng sau cùng mạng NAT có thể bị gộp nhầm thành 1 chuỗi tấn công | Kết hợp thêm định danh phiên (Session ID), User-Agent fingerprinting và JA3/JA4 TLS hash |
| **Giao diện Dashboard chỉ hiển thị 50 sự kiện** | Truy vấn API frontend cố định lấy 50 bản ghi gần nhất, thiếu phân trang (Pagination) | Chuyên viên phân tích SOC không thể duyệt ngược lịch sử sự kiện cũ trực tiếp trên UI | Bổ sung API hỗ trợ phân trang Server-side (Limit/Offset) và bộ lọc tìm kiếm nâng cao |
| **Thiếu quy trình xử lý sự cố (Incident Workflow)** | Dashboard không có nút gán người xử lý, chuyển trạng thái Acknowledge / Resolved | Hệ thống dừng lại ở mức hiển thị giám sát, chưa hỗ trợ quy trình phản ứng sự cố toàn diện | Xây dựng phân hệ quản lý vé sự cố (Incident Ticket Management) và phân quyền điều tra viên |
| **Cơ chế cập nhật Dashboard dùng Polling** | Frontend định kỳ gửi HTTP GET mỗi 3 giây; Redis cache tổng hợp 30 giây | Tạo tải dư thừa cho Web server và độ trễ cập nhật chỉ số tổng hợp chậm tới 30 giây | Nâng cấp sang giao thức truyền thông hai chiều thời gian thực (WebSockets hoặc Server-Sent Events) |
| **Chưa ánh xạ khung tri thức MITRE ATT&CK** | Các sự kiện và cảnh báo chưa được gắn nhãn Tactic và Technique ID của MITRE | Khó khăn cho việc đánh giá độ phủ an ninh và tự động hóa điều tra chuyên sâu | Xây dựng bảng ánh xạ ma trận kỹ thuật tấn công MITRE ATT&CK vào các quy tắc tương quan |
| **Dùng chung 1 khóa Ingest API Key** | Biến môi trường `INGEST_API_KEY` được dùng chung cho cả Web, Cowrie, Suricata và ML forwarders | Nếu một cảm biến biên bị lộ khóa, kẻ tấn công có thể giả mạo dữ liệu cho các nguồn còn lại | Triển khai cơ chế cấp phát API Key riêng biệt cho từng trạm cảm biến kèm phân quyền nguồn dữ liệu |

---

## 4.8. Danh mục tài liệu và tệp minh chứng thực nghiệm

Toàn bộ dữ liệu thực nghiệm đã được đóng gói đầy đủ trong tệp lưu trữ [chapter4_evidence.zip](file:///d:/A/A_5chai/honey_pot/chapter4_evidence.zip):

1.  **Báo cáo hiệu chỉnh chuẩn xác:** `chapter4_corrected_report.md` (Tài liệu này)
2.  **Biên bản rà soát sai lệch:** `chapter4_corrections.md`
3.  **Tệp dữ liệu kỹ thuật xác minh:** `chapter4_verified_facts.json`
4.  **Bảng nguồn gốc số liệu:** `chapter4_metric_provenance.csv`
5.  **Thông số thiết lập môi trường:** `experimental_setup.md`
6.  **Các tệp kết quả đo (CSV / JSON):**
    *   `ingestion_results.csv`: Dữ liệu kiểm thử tiếp nhận API từ 4 định dạng nguồn.
    *   `dedup_test_results.csv`: Dữ liệu kiểm thử cơ chế loại trừ trùng lặp (Deduplication).
    *   `web_detection_results.csv`: Bảng ma trận phát hiện 10 nhóm tấn công Web.
    *   `signature_detection_results.csv`: Kết quả kiểm thử 10 chữ ký Suricata và mẫu lành tính.
    *   `ml_metrics.json`: Toàn bộ chỉ số hiệu năng mô hình học máy trích xuất từ artifact chính thức.
    *   `ml_per_class_metrics.csv`: Bảng đo lường chi tiết 7 phân lớp của tập CICIoT2023.
    *   `correlation_results.csv`: Dữ liệu kiểm thử 4 luật tương quan và các đối chứng âm.
    *   `performance_results.csv`: Tập dữ liệu 500 yêu cầu đo độ trễ Ingest API.
    *   `latency_summary.json`: Bảng phân rã độ trễ từng phân đoạn hệ thống.
    *   `isolation_test_results.csv`: Kết quả 10 bài kiểm thử an toàn và cách ly mạng.
    *   `limitations_and_improvements.csv`: Danh mục 14 hạn chế kỹ thuật và giải pháp.
7.  **Thư mục ảnh chụp minh chứng chất lượng cao (`screenshots/` - Tuân thủ quy tắc không chứa số chương/mục, có ghi chú footnote runtime-derived illustration):**
    *   `runtime_services_status.png`: Trạng thái hoạt động thực tế của 21 container và xác thực Keycloak.
    *   `ingestion_pipeline_results.png`: Bảng minh chứng tiếp nhận API từ các định dạng nguồn.
    *   `deduplication_replay_evidence.png`: Nhật ký chứng minh Dedup và Forwarder Replay trong bảng `events`.
    *   `web_detection_matrix.png`: Bảng ma trận tỷ lệ phát hiện các lỗ hổng Web.
    *   `suricata_signatures_detection.png`: Bảng kiểm thử các chữ ký Suricata chuẩn theo `honeypot.rules`.
    *   `ml_confusion_matrix.png`: Biểu đồ ma trận nhầm lẫn của mô hình XGBoost trên 7 lớp CICIoT2023.
    *   `ml_per_class_metrics.png`: Biểu đồ trực quan hóa Precision, Recall và F1 của 7 lớp CICIoT2023.
    *   `correlation_rules_matrix.png`: Bảng ma trận kết quả kích hoạt luật tương quan và phân định độ trễ.
    *   `correlation_alert_postgres_evidence.png`: Bản ghi cảnh báo tương quan thực tế trong bảng `events` của PostgreSQL.
    *   `api_ingestion_latency_distribution.png`: Biểu đồ phân phối độ trễ tiếp nhận Ingest API.
    *   `latency_component_breakdown.png`: Biểu đồ phân rã độ trễ các thành phần hệ thống.
    *   `isolation_containment_matrix.png`: Bảng kiểm chứng an toàn và ngăn chặn độc hại.
    *   `upload_quarantine_storage.png`: Cấu trúc thư mục cách ly tệp độc hại thực tế dạng `.bin`.
    *   `dashboard_live_analytics.png`: Ảnh chụp thực tế giao diện giám sát SOC Dashboard.
8.  **Thư mục nhật ký thô (`raw/`):** Chứa toàn bộ logs thực thi nguyên bản của các bài kiểm thử tự động, kết quả truy vấn SQL và phản hồi API.
