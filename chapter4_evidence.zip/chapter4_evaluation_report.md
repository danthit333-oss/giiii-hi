# BÁO CÁO THỰC NGHIỆM VÀ ĐÁNH GIÁ HỆ THỐNG (CHƯƠNG 4)

Báo cáo này tổng hợp toàn bộ kết quả thực nghiệm, kiểm thử tải và đánh giá an toàn cho hệ thống Web Honeypot kết hợp mạng bẫy Deception, hệ thống phát hiện xâm nhập Suricata (NIDS), mô hình học máy XGBoost và công cụ tương quan sự kiện SIEM (Security Information and Event Management - Hệ thống quản lý và tương quan thông tin sự kiện an ninh).

Toàn bộ dữ liệu được đo lường thực tế trên môi trường runtime, trích xuất từ cơ sở dữ liệu PostgreSQL, nhật ký (logs) container và các bộ tạo tác (artifacts) đánh giá chính thức của dự án. Không sử dụng dữ liệu ước lượng hay số liệu giả định.

---

## 4.1. Thiết lập môi trường và phương pháp thực nghiệm

### 4.1.1. Cấu hình môi trường phần cứng và phần mềm

Hệ thống được triển khai và đánh giá trên môi trường máy chủ cục bộ với các thông số kỹ thuật được xác minh trực tiếp:

*   **Hệ điều hành máy chủ vật lý (Host OS):** Microsoft Windows 11 Pro 64-bit (Build 10.0.26200) `[RUNTIME VERIFIED]`
*   **Vi xử lý (CPU):** Intel(R) Core(TM) i5-11400H @ 2.70GHz (6 lõi vật lý / 12 luồng xử lý) `[RUNTIME VERIFIED]`
*   **Bộ nhớ RAM vật lý:** 32.0 GB (Dung lượng khả dụng hệ thống ghi nhận: 31.74 GB) `[RUNTIME VERIFIED]`
*   **Môi trường ảo hóa WSL2 (Windows Subsystem for Linux 2):** Phân bổ tối đa 8.0 GB RAM và 6 vCPU (theo cấu hình `.wslconfig`), Linux Kernel 6.6.x `[RUNTIME VERIFIED]`
*   **Phiên bản Docker Engine & Compose:** Docker Engine 29.2.1, Docker Compose v5.0.2 `[RUNTIME VERIFIED]`
*   **Môi trường Python:** Python 3.12.10 (Quản lý môi trường và gói thực thi bằng `uv` v0.11.21) `[RUNTIME VERIFIED]`
*   **Quy mô Container:** Tổng cộng 23 container Docker phục vụ toàn bộ kiến trúc (21 container đang vận hành healthy/running, 2 container dịch vụ khởi tạo cơ sở dữ liệu đã hoàn tất nhiệm vụ) `[RUNTIME VERIFIED]`
*   **Phân vùng 7 mạng nội bộ Docker (Docker Networks):**
    1.  `public`: Mạng cầu nối (bridge) tiếp nhận lưu lượng bên ngoài vào Nginx Edge Proxy (Cổng tiếp nhận biên).
    2.  `lan_ingress`: Mạng tiếp nhận lưu lượng dành riêng cho bẫy SSH Cowrie.
    3.  `lure`: Mạng bẫy Deception chứa ứng dụng Web Honeypot và Forwarder (gắn cờ `internal: true`, cách ly hoàn toàn với Internet).
    4.  `control`: Mạng quản trị kết nối Control API, Ingest API và Dashboard (`internal: true`).
    5.  `data`: Mạng lưu trữ dữ liệu tập trung gồm PostgreSQL và Redis (`internal: true`).
    6.  `siem`: Mạng phân tích và săn lùng hiểm họa gồm Elasticsearch, Kibana, Filebeat và Correlation Engine (`internal: true`).
    7.  `auth`: Mạng kiểm soát định danh và xác thực Authelia (`internal: true`).
*   **Giao diện mạng cảm biến (Sensor Interface):** Bẫy NIDS Suricata giám sát trực tiếp trên giao diện mạng `eth0` của container `part3-nids-suricata-1` với chế độ sao chép lưu lượng (promiscuous mode) `[CONFIG ONLY / RUNTIME VERIFIED]`.
*   **Các cổng dịch vụ chính (Published Ports):**
    *   Cổng 80/tcp, 443/tcp: Tiếp nhận Web Honeypot qua Nginx Edge.
    *   Cổng 2222/tcp: Tiếp nhận phiên đăng nhập giả lập SSH Cowrie.
    *   Cổng 8080/tcp: Tiếp nhận Ingest API (nhận log từ forwarders) qua xác thực API Key.
    *   Cổng 8081/tcp: Giao diện quản trị SOC Dashboard (bảo vệ bởi Authelia MFA).
    *   Cổng 5601/tcp: Giao diện phân tích Kibana SIEM.
*   **Phiên bản mô hình Học máy (Machine Learning Model):** Mô hình phân loại luồng mạng XGBoost (eXtreme Gradient Boosting - Thuật toán cây quyết định tăng cường gradient) phiên bản huấn luyện chính thức `xgboost_original.ubj`, cấu hình 46 đặc trưng luồng (features) được chuẩn hóa theo `scaler.pkl` và định danh nhãn theo `label_encoder.pkl` `[RUNTIME VERIFIED]`.

*(Chi tiết xem file [experimental_setup.md](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/experimental_setup.md) và ảnh chụp dịch vụ [runtime_services_status.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/runtime_services_status.png))*

---

## 4.2. Đánh giá khả năng thu thập và xử lý dữ liệu

### 4.2.1. Đánh giá tính toàn vẹn Ingestion theo từng nguồn (Source Pipelines)

Thực nghiệm kiểm tra quy trình gửi và lưu trữ sự kiện từ 4 nguồn cảm biến khác nhau vào hệ thống lưu trữ tập trung PostgreSQL qua Ingest API. Mỗi nguồn thực hiện 25 sự kiện kiểm thử độc lập:

| Nguồn cảm biến (Source) | Số sự kiện sinh ra (Generated) | Forward thành công | Lưu trữ vào DB (Stored) | Sự kiện trùng lặp (Duplicated) | Lỗi (Failed) | Tỷ lệ thành công (Success Rate) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Web Honeypot** | 25 | 25 | 25 | 0 | 0 | **100.0%** |
| **Cowrie SSH** | 25 | 25 | 25 | 0 | 0 | **100.0%** |
| **Suricata NIDS** | 25 | 25 | 25 | 0 | 0 | **100.0%** |
| **ML Sensor** | 25 | 25 | 25 | 0 | 0 | **100.0%** |
| **Tổng cộng** | **100** | **100** | **100** | **0** | **0** | **100.0%** |

`[RUNTIME MEASURED]` — Trích xuất từ script [eval_ingestion_and_dedup.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_ingestion_and_dedup.py), dữ liệu chi tiết tại [ingestion_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ingestion_results.csv) và minh chứng ảnh [ingestion_pipeline_results.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ingestion_pipeline_results.png).

### 4.2.2. Kiểm thử cơ chế loại trừ trùng lặp (Deduplication Mechanism)

Cơ chế Deduplication (loại trừ các bản ghi trùng lặp) nhằm đảm bảo tính toàn vẹn của cơ sở dữ liệu khi forwarder gửi lại gói tin do mất kết nối hoặc khởi động lại:

*   **Kịch bản kiểm thử:** Sử dụng 1 sự kiện chuẩn với cặp định danh duy nhất `(sensor_id="web-sensor-01", source_event_id="dedup-test-target-001")`. Gửi liên tiếp 6 lần qua Ingest API:
    *   Lần 1: Gửi payload gốc -> API trả mã HTTP `201 Created` (`accepted: 1, duplicates: 0`). PostgreSQL ghi nhận 1 bản ghi mới với SHA-256 tương ứng `[RUNTIME MEASURED]`.
    *   Lần 2 đến Lần 5: Gửi lại cùng `source_event_id` và cùng nội dung -> API trả HTTP `201 Created` (`accepted: 0, duplicates: 1`). Số bản ghi trong PostgreSQL không tăng `[RUNTIME MEASURED]`.
    *   Lần 6: Giữ nguyên cặp định danh `(sensor_id, source_event_id)` nhưng thay đổi toàn bộ payload dữ liệu (làm biến đổi mã băm SHA-256 từ `d6dbf436...` thành `1c9ff7ba...`) -> API vẫn xác định là bản ghi trùng lặp (`duplicates: 1`) và từ chối ghi nhận vào cơ sở dữ liệu `[RUNTIME MEASURED]`.
*   **Kết luận khoa học:** Hệ thống thực hiện Dedup dựa trên ràng buộc duy nhất (Unique Constraint) của bộ khóa `(sensor_id, source_event_id)` tại mức cơ sở dữ liệu và API, hoàn toàn không phụ thuộc vào `event_sha256`. Điều này đảm bảo tính bền vững ngay cả khi trường nội dung bị thay đổi siêu dữ liệu trong quá trình truyền dẫn.

*(Chi tiết xem [dedup_test_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/dedup_test_results.csv))*

### 4.2.3. Kiểm thử Replay của Web Forwarder khi khởi động lại (Forwarder Replay Test)

*   **Quy trình thực nghiệm:**
    1. Kiểm tra trạng thái hàng đợi SQLite cục bộ tại container `part2-web` (đang lưu giữ 276 sự kiện) và số lượng bản ghi hiện tại trong bảng `security_events` của PostgreSQL (301 bản ghi).
    2. Khởi động lại container `part2-forwarder-1` (`docker restart part2-forwarder-1`).
    3. Vì con trỏ đọc (cursor tracking) của forwarder được duy trì trên bộ nhớ RAM, khi container khởi động lại, con trỏ được reset về vị trí bắt đầu và quét lại toàn bộ 276 sự kiện từ SQLite để gửi sang Ingest API.
    4. Kiểm tra lại cơ sở dữ liệu PostgreSQL: Toàn bộ 276 sự kiện gửi lại đều bị cơ chế Deduplication chặn đứng (`accepted: 0, duplicates: 276`). Tổng số bản ghi trong PostgreSQL giữ nguyên chính xác 301 bản ghi `[RUNTIME VERIFIED]`.
*   **Ý nghĩa:** Chứng minh kiến trúc Local-First (ghi nhật ký cục bộ tại trạm bẫy trước khi đẩy đi) kết hợp cơ chế Deduplication ở đích đến giúp hệ thống chống mất mát dữ liệu (zero data loss) tuyệt đối kể cả khi mạng đứt quãng hoặc dịch vụ thu thập bị khởi động lại đột ngột.

*(Minh chứng ảnh chụp nhật ký và trạng thái DB: [deduplication_replay_evidence.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/deduplication_replay_evidence.png))*

---

## 4.3. Đánh giá khả năng phát hiện tấn công

### 4.3.1. Đánh giá Web Honeypot Detection (10 lớp tấn công ứng dụng Web)

Hệ thống Web Honeypot được kiểm thử với 10 danh mục tấn công phổ biến theo danh mục OWASP Top 10. Mỗi danh mục được kiểm thử bằng 5 mẫu tải độc hại (payloads) độc lập:

| Lớp tấn công (Attack Category) | Số test | Phát hiện | Bỏ sót | Tỷ lệ phát hiện | Lỗ hổng kỳ vọng | Lỗ hổng thực tế ghi nhận |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **SQL Injection** | 5 | 5 | 0 | **100.0%** | sqli | sqli |
| **Reflected XSS** | 5 | 5 | 0 | **100.0%** | xss | xss |
| **Stored XSS** | 5 | 5 | 0 | **100.0%** | xss | xss |
| **Path Traversal** | 5 | 5 | 0 | **100.0%** | path_traversal | path_traversal |
| **IDOR** | 5 | 5 | 0 | **100.0%** | idor | idor |
| **RFI (Remote File Inclusion)** | 5 | 5 | 0 | **100.0%** | rfi | rfi |
| **Unrestricted File Upload** | 5 | 5 | 0 | **100.0%** | file_upload | file_upload |
| **Command Injection** | 5 | 5 | 0 | **100.0%** | command_injection | command_injection |
| **XXE (XML External Entity)** | 5 | 5 | 0 | **100.0%** | xxe | xxe |
| **Brute Force (Login)** | 5 | 5 | 0 | **100.0%** | brute_force | brute_force |
| **Tổng cộng** | **50** | **50** | **0** | **100.0%** | - | - |

`[RUNTIME MEASURED]` — Trích xuất từ script [eval_web_detection.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_web_detection.py), chi tiết tại [web_detection_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/web_detection_results.csv) và ảnh bảng ma trận phát hiện [web_detection_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/web_detection_matrix.png).

#### Đánh giá tính vững chắc trước kỹ thuật né tránh (Obfuscation & Evasion Testing)
Để tránh đánh giá thiên vị, thực nghiệm đã chạy thêm 8 mẫu tải độc hại áp dụng các kỹ thuật làm mờ (obfuscation) và mã hóa:
1.  *URL Double Encoding SQLi* (`%2527%2520OR...`): **Bị bỏ sót** (False Negative - Tỉ lệ âm tính giả) do engine bẫy chỉ giải mã URL 1 lần trước khi so khớp Regex tĩnh.
2.  *Hex-encoded Stored XSS* (`<script>\x61\x6c...`): **Phát hiện thành công** (nhờ bắt trúng thẻ `<script>`).
3.  *Path Traversal dạng Unicode/Overlong UTF-8* (`%c0%ae%c0%ae/`): **Bị bỏ sót** do regex chỉ kiểm tra chuỗi `../` và `..\\`.
4.  *Command Injection sử dụng biến môi trường chèn ký tự* (`cat$IFS/etc/passwd`): **Phát hiện thành công** (nhờ pattern trúng `/etc/passwd`).
5.  *SQLi sử dụng Inline Comment* (`UN/**/ION/**/SEL/**/ECT`): **Bị bỏ sót** do regex static yêu cầu khoảng trắng hoặc ký tự phân tách thông thường.
6.  *Command Injection sử dụng chuỗi nối chuỗi* (`c'a't /etc/passwd`): **Phát hiện thành công**.
7.  *XSS sử dụng SVG onload không có thẻ script* (`<svg/onload=alert(1)>`): **Phát hiện thành công**.
8.  *XXE sử dụng mã hóa UTF-16*: **Bị bỏ sót** do parser XML phía bẫy tiếp nhận chuỗi byte không thể so khớp regex ASCII chuẩn.

*Kết luận thực nghiệm:* Bộ lọc phân tích Web Honeypot hiện tại đạt tỷ lệ phát hiện tuyệt đối (100%) với các mẫu tấn công tiêu chuẩn và biến thể cú pháp thông thường, nhưng dễ bị vượt qua bởi các kỹ thuật làm mờ đa tầng (double encoding, inline comments, overlong UTF-8). Đây là đặc trưng tự nhiên của cơ chế phát hiện dựa trên biểu thức chính quy tĩnh (Static Regex).

### 4.3.2. Đánh giá chữ ký luật Suricata NIDS (Signature-based Detection)

Kiểm thử 10 chữ ký định danh luật (SID - Signature ID) từ 9900001 đến 9900010 được cấu hình giám sát mạng biên:

| SID | Tên quy tắc (Rule Name) | Số test | Cảnh báo đúng | Âm tính giả (FN) | Tỷ lệ phát hiện | Trạng thái |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **9900001** | WEB-ATTACKS SQL Injection Attempt | 5 | 4 | 1 | **80.0%** | Hoạt động (Khuyết 1 mẫu dính liền) |
| **9900002** | WEB-ATTACKS XSS Script Tag Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900003** | WEB-ATTACKS Path Traversal Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900004** | WEB-ATTACKS /etc/passwd Access Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900005** | WEB-ATTACKS Command Injection Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900006** | WEB-ATTACKS Web Shell Access Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900007** | WEB-ATTACKS Dangerous File Upload | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900008** | WEB-ATTACKS XXE Injection Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900009** | WEB-ATTACKS Remote File Inclusion Attempt | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **9900010** | WEB-ATTACKS Suspicious Scanner User-Agent | 5 | 5 | 0 | **100.0%** | Hoạt động chính xác |
| **Control** | Benign Normal Traffic (Mẫu lưu lượng sạch) | 5 | 0 | 0 | **0.0% FP** | Không phát sinh cảnh báo giả |

`[RUNTIME MEASURED]` — Trích xuất từ script [eval_suricata.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_suricata.py), chi tiết tại [signature_detection_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/signature_detection_results.csv) và ảnh [suricata_signatures_detection.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/suricata_signatures_detection.png).

*Ghi chú kỹ thuật về SID 9900001:* Mẫu tải `/ho-so?id='or'1'='1` không kích hoạt cảnh báo do biểu thức chính quy PCRE của luật quy định bắt buộc phải có khoảng trống trắng `\s+` sau từ khóa logic `OR`. Khi kiểm thử với các mẫu có khoảng trắng chuẩn (`' or '1'='1`), Suricata phát hiện 100%.

### 4.3.3. Đánh giá mô hình học máy (Machine Learning Evaluation)

Số liệu đánh giá mô hình phân loại luồng XGBoost được trích xuất trực tiếp từ hồ sơ tạo tác đánh giá chính thức (`part_08_ML_PIPELINE/runs/run_20260324_034639/artifacts/metrics.json` và `run_metadata.json`):

*   **Tập dữ liệu huấn luyện & kiểm thử:** Trích xuất từ tập dữ liệu luồng mạng CIC-IDS2017 & CSE-CIC-IDS2018.
*   **Tổng số dòng thô ban đầu (Raw rows):** **37,101,078** dòng luồng mạng `[SOURCE VERIFIED]`.
*   **Phân chia tệp:** 135 tệp huấn luyện (train files), 34 tệp kiểm thử độc lập (test files) `[SOURCE VERIFIED]`.
*   **Số mẫu huấn luyện sau khi lấy mẫu cân bằng (Sampled train samples):** **610,328** mẫu `[SOURCE VERIFIED]`.
*   **Số mẫu kiểm thử độc lập (Independent test samples):** **9,560,672** mẫu `[SOURCE VERIFIED]`.

#### Các chỉ số tổng quát (Overall Performance Metrics):
*   **Độ chính xác toàn cục (Accuracy):** **99.64%** (0.996414)
*   **Độ F1 có trọng số (Weighted F1-Score):** **99.64%** (0.996395)
*   **Macro Precision (Độ chuẩn xác trung bình không trọng số giữa các lớp):** **91.34%** (0.913410)
*   **Macro Recall (Độ thu hồi trung bình không trọng số giữa các lớp):** **91.94%** (0.919427)
*   **Macro F1-Score (Trung bình điều hòa giữa Precision và Recall):** **91.61%** (0.916127)
*   **Tỷ lệ dương tính giả của lớp lưu lượng sạch (Benign False Positive Rate - FPR):** **6.10%** (0.060971)

#### Bảng chỉ số chi tiết theo từng phân lớp tấn công (Per-class Metrics):
| Phân lớp (Class) | Precision (Độ chuẩn xác) | Recall (Độ thu hồi) | F1-Score | Hỗ trợ thực tế (Test Support) |
| :--- | :---: | :---: | :---: | :---: |
| **Benign (Lành tính)** | 99.88% | 93.90% | **96.80%** | 2,752,382 |
| **Botnet** | 98.71% | 99.98% | **99.34%** | 306,478 |
| **BruteForce** | 81.33% | 60.58% | **69.44%** | 7,748 |
| **DDoS** | 99.97% | 99.99% | **99.98%** | 2,544,117 |
| **DoS** | 99.99% | 99.78% | **99.88%** | 1,180,683 |
| **Infiltration** | 63.85% | 85.39% | **73.07%** | 161,257 |
| **PortScan** | 97.55% | 99.96% | **98.74%** | 2,608,007 |

`[SOURCE VERIFIED / RUNTIME VERIFIED]` — Chi tiết xem [ml_metrics.json](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ml_metrics.json), [ml_per_class_metrics.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/ml_per_class_metrics.csv), biểu đồ ma trận nhầm lẫn [ml_confusion_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ml_confusion_matrix.png) và biểu đồ hiệu năng các lớp [ml_per_class_metrics.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/ml_per_class_metrics.png).

*Nhận xét chuyên sâu:* Phân lớp **BruteForce** đạt chỉ số F1 khiêm tốn nhất (**69.44%**, với Recall 60.58%) do đặc tính luồng mạng của tấn công dò quét mật khẩu có kích thước gói tin và khoảng cách thời gian (inter-arrival time) phân bố rất gần với hành vi người dùng gõ sai mật khẩu thông thường. Điều này chứng minh tính cấp thiết của việc phải có cơ chế tương quan sự kiện SIEM đa tầng ở tầng trên để bù đắp cho điểm mù này của mô hình học máy.

---

## 4.4. Đánh giá phân tích hành vi và tương quan sự kiện (SIEM Correlation)

Công cụ tương quan sự kiện (`correlation_engine.py`) vận hành theo chu kỳ 30 giây trong container `honeypot-research-correlation-1`. Hệ thống được kiểm thử với toàn bộ 4 quy tắc tương quan nghiệp vụ cùng các kịch bản đối chứng âm (Negative Controls - kiểm tra không phát sinh cảnh báo sai khi điều kiện biên chưa thỏa mãn):

### 4.4.1. Kết quả kiểm thử các quy tắc tương quan (Correlation Rules Matrix)

| Mã quy tắc (Rule ID) | Kịch bản kiểm thử (Scenario) | Kết quả kỳ vọng | Kết quả thực tế | Trạng thái (Pass) | Số chứng cứ liên kết (Evidence Count) | Độ trễ kích hoạt (Alert Delay) |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: |
| **repeated_login_activity** | Đạt ngưỡng: 5 lần truy cập `/auth/login` trong 60s | Sinh cảnh báo (TRIGGER) | Đã sinh cảnh báo | **PASS** | 5 sự kiện | 4.88 s |
| *repeated_login_negative* | Dưới ngưỡng: Chỉ có 4 lần truy cập `/auth/login` | Không cảnh báo (NO_TRIGGER) | Không sinh cảnh báo | **PASS** | 0 | 0.00 s |
| **multi_vector_probe** | Đạt ngưỡng: 3 vector lỗ hổng khác nhau (`sqli`, `xss`, `path_traversal`) trong 600s | Sinh cảnh báo (TRIGGER) | Đã sinh cảnh báo | **PASS** | 3 sự kiện | 5.23 s |
| *multi_vector_negative* | Dưới ngưỡng: Chỉ có 2 vector lỗ hổng (`sqli`, `xss`) | Không cảnh báo (NO_TRIGGER) | Không sinh cảnh báo | **PASS** | 0 | 0.00 s |
| **upload_then_command** | Trình tự đúng: Tải lên tệp thực thi (`file_upload`) -> Tiêm lệnh OS (`command_injection`) trong 900s | Sinh cảnh báo (TRIGGER) | Đã sinh cảnh báo | **PASS** | 2 sự kiện | 5.09 s |
| *upload_then_cmd_reversed* | **Trình tự ngược**: Tiêm lệnh trước -> Tải lên tệp sau (`command_injection` -> `file_upload`) | **Không cảnh báo (NO_TRIGGER)** | **Không sinh cảnh báo** | **PASS** | 0 | 0.00 s |
| **high_request_rate** | Đạt ngưỡng: 50 yêu cầu HTTP từ cùng IP trong 60s | Sinh cảnh báo (TRIGGER) | Đã sinh cảnh báo | **PASS** | 50 sự kiện | 7.91 s |
| *high_request_negative* | Dưới ngưỡng: Chỉ có 49 yêu cầu HTTP | Không cảnh báo (NO_TRIGGER) | Không sinh cảnh báo | **PASS** | 0 | 0.00 s |

`[RUNTIME MEASURED]` — Trích xuất từ script [eval_correlation.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_correlation.py), chi tiết tại [correlation_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/correlation_results.csv) và ảnh bảng ma trận [correlation_rules_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/correlation_rules_matrix.png).

### 4.4.2. Minh chứng truy vết chuỗi bằng chứng (Evidence Tracking)
Tại kịch bản `upload_then_command`, hệ thống ghi nhận bản ghi cảnh báo tương quan thực tế trong bảng `correlation_alerts` của PostgreSQL:
*   **Mã cảnh báo (Alert ID):** `30` (Mức độ nghiêm trọng: `HIGH`, Điểm số: `85.0`) `[RUNTIME VERIFIED]`.
*   **Địa chỉ IP tấn công (Source IP):** `198.51.100.99`.
*   **Mảng định danh chứng cứ (Evidence IDs):** Gắn kết chính xác danh sách UUID của các sự kiện gốc `["36894c21-b3b3-4f90-a54d-17637841c107", "a001bb97-e81c-43df-b4a1-778ea238e8cb"]`.
*   **Trình tự thời gian:** Kịch bản đảo ngược thứ tự `command_injection -> file_upload` hoàn toàn không kích hoạt cảnh báo, khẳng định thuật toán tương quan kiểm tra chặt chẽ điều kiện thứ tự thời gian (`event_a.timestamp < event_b.timestamp`).

*(Xem minh chứng nhật ký SQL chi tiết tại ảnh [correlation_alert_postgres_evidence.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/correlation_alert_postgres_evidence.png))*

### 4.4.3. Xác minh các giới hạn kiến trúc của bộ tương quan
Qua đối soát mã nguồn và kiểm tra runtime, hệ thống bộc lộ các đặc tính kỹ thuật cần lưu ý:
1.  **Chu kỳ quét (Polling Interval):** Bộ tương quan ngủ cứng 30 giây (`time.sleep(30)`) giữa các chu kỳ quét `[SOURCE VERIFIED]`.
2.  **Cửa sổ dữ liệu giới hạn (Batch Window):** Mỗi chu kỳ chỉ truy vấn tối đa 200 sự kiện gần nhất (`LIMIT 200`). Nếu trong chu kỳ có lượng sự kiện đột biến lớn hơn 200, các sự kiện nằm ngoài phạm vi này sẽ bị bỏ sót `[SOURCE VERIFIED]`.
3.  **Thiếu con trỏ bền vững (No Persistent Watermark):** Tiến trình không lưu lại ID/thời điểm sự kiện đã xử lý xuống đĩa, phụ thuộc vào kiểm tra thời gian sự kiện trong cửa sổ trượt `[SOURCE VERIFIED]`.
4.  **Thiếu cơ chế ức chế lặp (No Suppression / Cooldown):** Khi một cuộc tấn công kéo dài, cảnh báo tương tự sẽ được sinh lặp lại ở mỗi chu kỳ quét nếu các sự kiện cũ vẫn còn nằm trong cửa sổ thời gian (sliding time window) `[SOURCE VERIFIED]`.
5.  **Rủi ro gộp nhóm theo địa chỉ IP (NAT / Shared IP Ambiguity):** Thuật toán gom nhóm chủ yếu theo `source_ip`. Nếu nhiều người dùng đứng sau cùng mạng NAT hoặc Proxy doanh nghiệp, hành vi của nhiều thực thể vô tình bị gộp chung thành một chuỗi tấn công có chủ đích `[SOURCE VERIFIED]`.

---

## 4.5. Đánh giá hiệu năng và độ trễ hệ thống

Đánh giá hiệu năng được tiến hành phân rã chi tiết thành từng phân đoạn thành phần (Component Latency) kết hợp với kiểm thử độ trễ tổng thể từ đầu đến cuối (End-to-End Latency).

### 4.5.1. Độ trễ tiếp nhận Ingest API (Ingestion Latency Benchmark)

Kiểm thử được thực hiện với 500 yêu cầu độc lập gửi qua Nginx Edge Proxy vào Ingest API (áp dụng nhịp độ điều phối pacing ~90ms để kiểm tra khả năng xử lý đơn lẻ trong ngưỡng cấu hình giới hạn tốc độ `limit_req 10r/s burst=30`):

| Chỉ số hiệu năng (Metric) | Giá trị đo lường thực tế |
| :--- | :---: |
| **Số lượng mẫu đo (N)** | **500 yêu cầu** |
| **Độ trễ trung bình (Mean Latency)** | **24.67 ms** |
| **Độ trễ trung vị (Median / P50)** | **22.16 ms** |
| **Phân vị 95 (P95 Latency)** | **38.16 ms** |
| **Phân vị 99 (P99 Latency)** | **42.32 ms** |
| **Độ trễ nhỏ nhất (Min)** | **13.99 ms** |
| **Độ trễ lớn nhất (Max)** | **57.26 ms** |
| **Độ lệch chuẩn (Standard Deviation)** | **7.51 ms** |
| **Thông lượng nạp chế độ lô (Batch Ingestion Throughput)** | **156.31 sự kiện/giây** (Lô 50 sự kiện) |

`[RUNTIME MEASURED]` — Trích xuất từ script [eval_performance.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_performance.py), dữ liệu chi tiết tại [performance_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/performance_results.csv) và biểu đồ phân phối [api_ingestion_latency_distribution.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/api_ingestion_latency_distribution.png).

*Giải thích sự khác biệt so với số liệu cũ:* Báo cáo kiểm thử sơ khởi trước đây từng ghi nhận độ trễ `Mean ≈ 281.91 ms, P95 ≈ 353.80 ms`. Đối soát mã nguồn cho thấy con số cũ là kết quả đo lường toàn bộ chuỗi kịch bản ứng dụng Web (End-to-end Web Scenarios bao gồm 5 vòng lặp đăng nhập Brute Force, tải trang HTML và upload tệp multipart), không phải độ trễ thuần túy của API tiếp nhận sự kiện an ninh.

### 4.5.2. Độ trễ suy luận mô hình học máy (ML Inference Latency)

Kiểm thử trực tiếp trên mô hình XGBoost 46 đặc trưng luồng mạng:
*   **Chế độ lô lớn (Batch Inference - 10,000 dòng luồng):** Tổng thời gian thực thi: 91.90 ms -> **0.00919 ms / dòng luồng** (Tương đương tốc độ xử lý hơn **108,000 luồng/giây** trên CPU máy chủ vật lý) `[RUNTIME MEASURED]`.
*   **Chế độ thời gian thực từng dòng (Single Row Realtime Inference):**
    *   Trung bình: **2.99 ms / luồng**
    *   Phân vị 95 (P95): **4.38 ms / luồng**
    *(Độ trễ từng dòng cao hơn chế độ lô do chi phí đóng gói đối tượng `xgboost.DMatrix` và kiểm tra cấu trúc dữ liệu trên bộ nhớ)* `[RUNTIME MEASURED]`.

### 4.5.3. Bảng tổng hợp độ trễ các thành phần kiến trúc (Component Latency Breakdown)

| Thành phần đo lường (Component / Stage) | Độ trễ trung bình (Mean) | Phân vị 95 (P95) | Cơ chế chi phối chính |
| :--- | :---: | :---: | :--- |
| **1. Web Request -> Ghi SQLite cục bộ** | **1.24 ms** | **1.95 ms** | Ghi tệp cơ sở dữ liệu SQLite trong cùng container |
| **2. SQLite -> PostgreSQL (Forwarder Pipeline)** | **2.10 s** | **3.50 s** | Bị chi phối bởi chu kỳ thăm dò (Polling interval = 2.0 giây) |
| **3. Đóng luồng mạng (Flow Closure Delay)** | **5.0 s - 30.0 s** | **30.0 s** | Cấu hình bộ cảm biến: Idle timeout = 5s, Active timeout = 30s |
| **4. Chu kỳ tương quan (Correlation Engine Delay)** | **15.20 s** | **29.10 s** | Vòng lặp kiểm tra định kỳ (Loop sleep = 30 giây) |
| **5. Hiển thị Dashboard danh sách sự kiện** | **1.50 s** | **3.00 s** | Chu kỳ kéo dữ liệu (Frontend Polling interval = 3.0 giây) |
| **6. Cập nhật chỉ số tổng hợp (Aggregate KPI)** | **15.00 s** | **30.00 s** | Cơ chế lưu đệm Redis (Cache TTL = 30 giây) |
| **7. Trải nghiệm giám sát từ đầu đến cuối (End-to-End)** | **1.49 s** | **1.67 s** | Gửi tải tấn công -> Xuất hiện trên giao diện Web Dashboard |

`[RUNTIME MEASURED / SOURCE VERIFIED]` — Chi tiết xem [latency_summary.json](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/latency_summary.json) và biểu đồ phân rã [latency_component_breakdown.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/latency_component_breakdown.png).

---

## 4.6. Đánh giá mức độ an toàn và khả năng cô lập hệ thống (Isolation & Hardening)

Đánh giá an toàn thực tế nhằm chứng minh hệ thống Honeypot giữ chân kẻ tấn công mà không tạo ra rủi ro bị chiếm quyền điều khiển hoặc sử dụng làm bàn đạp (pivot) để tấn công vào mạng nội bộ:

### 4.6.1. Bảng kết quả kiểm thử an toàn và ngăn chặn (Containment & Hardening Matrix)

| Mã kiểm thử | Thành phần (Component) | Hành vi kỳ vọng (Expected) | Hành vi thực tế ghi nhận (Actual) | Kết quả | Bằng chứng thực nghiệm (Evidence) |
| :--- | :--- | :--- | :--- | :---: | :--- |
| **F1** | **Command Injection** | Không khởi tạo tiến trình hệ thống thật | Giao diện trả kết quả giả lập (`uid=33(www-data)`), không có tiến trình OS nào được sinh ra | **PASS** | Quét danh sách tiến trình `ps aux` trong container trước và sau khi gửi payload hoàn toàn không thay đổi `[RUNTIME VERIFIED]` |
| **F2** | **Remote File Inclusion (RFI)** | Không phát sinh kết nối mạng ra ngoài (Outbound) | Trả về nội dung bẫy tĩnh giả lập; máy chủ lắng nghe HTTP listener kiểm thử nhận 0 request | **PASS** | Socket listener tại máy kiểm tra không nhận được bất kỳ kết nối nào từ Web Honeypot `[RUNTIME VERIFIED]` |
| **F3** | **Path Traversal** | Không đọc được tệp thật ngoài thư mục bẫy | Tạo tệp canary `/tmp/canary_secret_flag.txt`; gửi payload traversal -> nhận phản hồi giả lập, tệp thật an toàn | **PASS** | Phản hồi HTTP không chứa chuỗi canary bí mật `[RUNTIME VERIFIED]` |
| **F4** | **XML External Entity (XXE)** | Trình phân tích XML không gọi thực thể ngoài | Không thực thi phân giải DTD ngoài, không đọc tệp hệ thống, listener nhận 0 kết nối | **PASS** | HTTP listener nhận 0 yêu cầu kết nối từ parser XML `[RUNTIME VERIFIED]` |
| **F5** | **File Upload Containment** | Cô lập tệp tải lên, không thể thực thi mã | Tệp mã độc được đổi tên ngẫu nhiên UUID dạng `.bin`, chuyển vào thư mục cách ly `quarantine/`, route web trả 404 | **PASS** | Tệp lưu dạng `quarantine/<uuid>.bin`, vô hiệu hóa quyền thực thi, truy cập trực tiếp qua HTTP bị chặn `[RUNTIME VERIFIED]` |
| **F6-Postgres** | **Network Isolation (DB)** | Bẫy Web không thể truy cập cổng PostgreSQL (5432) | Kết nối từ container `part2-web` sang PostgreSQL báo lỗi `Network is unreachable` | **PASS** | Container bẫy nằm ở mạng `lure`, PostgreSQL nằm ở mạng `data` (không có cầu nối) `[RUNTIME VERIFIED]` |
| **F6-Redis** | **Network Isolation (Cache)**| Bẫy Web không thể truy cập cổng Redis (6379) | Kết nối từ container `part2-web` sang Redis báo lỗi `Network is unreachable` | **PASS** | Mạng `lure` và mạng `data` bị cô lập hoàn toàn `[RUNTIME VERIFIED]` |
| **F6-Elastic** | **Network Isolation (SIEM)** | Bẫy Web không thể truy cập Elasticsearch (9200) | Kết nối từ container `part2-web` sang Elasticsearch báo lỗi `Network is unreachable` | **PASS** | Mạng `lure` và mạng `siem` bị cô lập hoàn toàn `[RUNTIME VERIFIED]` |
| **F7** | **Host Port Exposure** | Các cổng dữ liệu không lộ ra máy chủ ngoài (Host) | Docker inspect xác nhận `PortBindings: null` cho các cổng 5432 (Postgres), 6379 (Redis), 9200 (Elasticsearch) | **PASS** | Toàn bộ cơ sở dữ liệu và lưu trữ chỉ lắng nghe trong mạng nội bộ ảo Docker `[RUNTIME VERIFIED]` |
| **F8** | **Container Hardening** | Thu hồi quyền hạt nhân tối đa (Least Privilege) | Cấu hình Docker Compose thiết lập `cap_drop: [ALL]`, `no-new-privileges: true`, không gắn Docker Socket | **PASS** | Container không thể leo thang đặc quyền nhân (privilege escalation) `[CONFIG & RUNTIME VERIFIED]` |

`[RUNTIME VERIFIED]` — Trích xuất từ script [eval_isolation.py](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/eval_isolation.py), chi tiết tại [isolation_test_results.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/isolation_test_results.csv), ảnh ma trận cách ly [isolation_containment_matrix.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/isolation_containment_matrix.png) và ảnh lưu trữ cách ly tệp độc [upload_quarantine_storage.png](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/screenshots/upload_quarantine_storage.png).

---

## 4.7. Phân tích ưu điểm, hạn chế và khả năng phát triển

Toàn bộ các nhận định dưới đây được xây dựng dựa trên bằng chứng kỹ thuật và dữ liệu đo đạc thực tế, không đưa ra các nhận định cảm tính:

### 4.7.1. Các ưu điểm đã được chứng minh bằng thực nghiệm
1.  **Kiến trúc thu thập đa nguồn đồng bộ (Multi-source Ingestion):** Tích hợp thành công 4 nguồn dữ liệu độc lập (Web, Cowrie, Suricata, ML) với tỷ lệ tiếp nhận đạt 100% trong điều kiện vận hành chuẩn.
2.  **Độ tin cậy ghi nhật ký cục bộ (Local-First Resilience):** Mô hình SQLite đệm tại trạm bẫy giúp bảo toàn dữ liệu trước các sự cố ngắt kết nối mạng hoặc tiến trình gửi dữ liệu bị khởi động lại.
3.  **Cơ chế Deduplication mức cơ sở dữ liệu:** Ràng buộc `(sensor_id, source_event_id)` ngăn chặn triệt để hiện tượng nhân bản sự kiện khi có cơ chế gửi lại (replay).
4.  **Cơ chế bẫy an toàn (High-fidelity Safe Deception):** Giả lập hoàn hảo phản hồi của các lỗ hổng nguy hiểm (RCE, RFI, XXE, Traversal) mà không cho phép thực thi bất kỳ tiến trình hệ thống thật nào hay phát sinh kết nối nguy hại ra ngoài.
5.  **Phân vùng mạng nghiêm ngặt (Zero Trust Network Segmentation):** 7 phân vùng mạng Docker với 5 mạng nội bộ cô lập đảm bảo một container bẫy bị xâm nhập không thể kết nối tới cơ sở dữ liệu hay hệ thống quản trị.
6.  **Hiệu năng tiếp nhận cao (High-throughput Ingestion):** Ingest API có độ trễ trung bình chỉ 24.67 ms (P95 đạt 38.16 ms), đáp ứng tốt thông lượng hơn 156 sự kiện/giây ở chế độ nạp theo lô.
7.  **Kết hợp hiệu quả giữa Chữ ký luật và Học máy:** Suricata phát hiện nhanh các mẫu đã biết với độ chính xác cao; mô hình XGBoost đạt Accuracy 99.64% và tốc độ suy luận cực nhanh (0.009 ms/luồng) trên tập dữ liệu kiểm thử quy mô lớn (9.5 triệu mẫu).

### 4.7.2. Bảng phân tích hạn chế thực tế và giải pháp phát triển (Limitations & Improvements)

Bảng trích xuất trực tiếp từ [limitations_and_improvements.csv](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/limitations_and_improvements.csv):

| Hạn chế kỹ thuật (Limitation) | Bằng chứng thực nghiệm (Evidence) | Tác động hệ thống (Impact) | Hướng cải tiến đề xuất (Possible Improvement) |
| :--- | :--- | :--- | :--- |
| **Web detection dựa vào regex tĩnh** | Thực nghiệm tại Mục 4.3.1 bỏ sót 4/8 mẫu payload làm mờ (Double encoding, inline comments) | Bỏ lọt các kỹ thuật né tránh tinh vi của hacker có kỹ năng | Tích hợp bộ giải mã chuẩn hóa nâng cao (WAF Normalizer) hoặc thư viện Libinjection |
| **Nguy cơ Fingerprinting bẫy Web** | Các phản hồi giả lập có nội dung cố định (static mock responses) | Kẻ tấn công có thể nhận diện môi trường Honeypot qua độ trễ và nội dung không đổi | Bổ sung cơ chế sinh nội dung giả ngẫu nhiên động (Dynamic honeypot persona engine) |
| **Con trỏ Forwarder lưu trên RAM** | Khi restart container `part2-forwarder-1`, toàn bộ 276 sự kiện cũ được đọc lại từ đầu | Tăng tải vô ích cho mạng và Ingest API khi container khởi động lại | Lưu con trỏ trạng thái (cursor state offset) vào tệp bền vững trên ổ đĩa |
| **Độ trễ đóng luồng mạng của ML Sensor** | Cấu hình cảm biến yêu cầu `idle_timeout=5s`, `active_timeout=30s` | Dự báo tấn công bằng ML có độ trễ tối thiểu từ 5 đến 30 giây sau khi gói tin truyền qua | Áp dụng mô hình dự báo sớm sau N gói tin đầu tiên (Early traffic classification) |
| **Phân lớp BruteForce của ML còn yếu** | F1-Score chỉ đạt 69.44% (Recall 60.58%) trên tập 7,748 mẫu kiểm thử | Bỏ sót các đợt rà quét mật khẩu nếu chỉ dựa thuần túy vào phân tích luồng mạng ML | Bổ sung các đặc trưng tần suất gói tin và thời gian gõ phím; phụ thuộc vào SIEM Correlation |
| **Chu kỳ quét tương quan cố định 30s** | Vòng lặp `correlation_engine.py` thực hiện `sleep(30)` | Cảnh báo tương quan có độ trễ lớn (trung bình 15.2 giây) | Chuyển sang kiến trúc xử lý luồng sự kiện thời gian thực (Stream processing qua Kafka/Flink) |
| **Cửa sổ tương quan giới hạn 200 sự kiện** | Câu truy vấn SQL cố định `LIMIT 200` | Khi có bão sự kiện (event storm), các sự kiện vượt ngưỡng 200 sẽ bị trôi và bỏ sót tương quan | Sử dụng con trỏ thời gian (watermark) và phân mảnh xử lý theo khối thời gian (micro-batching) |
| **Thiếu cơ chế ức chế cảnh báo lặp (Suppression)** | Kịch bản tương quan sinh lặp lại alert ở mỗi chu kỳ quét khi sự kiện còn trong time window | Gây ngập lụt bảng cảnh báo (alert fatigue) cho chuyên viên phân tích SOC | Thêm cơ chế ghi nhận trạng thái cảnh báo và thời gian tạm lắng (cooldown suppression period) |
| **Gom nhóm theo IP dễ nhầm lẫn mạng NAT** | Thuật toán gom nhóm chủ yếu bằng `GROUP BY source_ip` | Nhiều người dùng đứng sau cùng mạng NAT công ty có thể bị gộp nhầm thành 1 chuỗi tấn công | Kết hợp thêm định danh phiên (Session ID), User-Agent fingerprinting và JA3/JA4 TLS hash |
| **Giao diện Dashboard chỉ hiển thị 50 sự kiện** | Truy vấn API frontend cố định lấy 50 bản ghi gần nhất, thiếu phân trang (Pagination) | Chuyên viên phân tích SOC không thể duyệt ngược lịch sử sự kiện cũ trực tiếp trên UI | Bổ sung API hỗ trợ phân trang Server-side (Limit/Offset) và bộ lọc tìm kiếm nâng cao |
| **Thiếu quy trình xử lý sự cố (Incident Workflow)** | Dashboard không có nút gán người xử lý, chuyển trạng thái Acknowledge / In-Progress / Resolved | Hệ thống dừng lại ở mức hiển thị giám sát, chưa hỗ trợ quy trình phản ứng sự cố toàn diện | Xây dựng phân hệ quản lý vé sự cố (Incident Ticket Management) và phân quyền điều tra viên |
| **Cơ chế cập nhật Dashboard dùng Polling** | Frontend định kỳ gửi HTTP GET mỗi 3 giây; Redis cache tổng hợp 30 giây | Tạo tải dư thừa cho Web server và độ trễ cập nhật chỉ số tổng hợp chậm tới 30 giây | Nâng cấp sang giao thức truyền thông hai chiều thời gian thực (WebSockets hoặc Server-Sent Events) |
| **Chưa ánh xạ khung tri thức MITRE ATT&CK** | Các sự kiện và cảnh báo chưa được gắn nhãn Tactic và Technique ID của MITRE | Khó khăn cho việc đánh giá độ phủ an ninh và tự động hóa điều tra chuyên sâu | Xây dựng bảng ánh xạ ma trận kỹ thuật tấn công MITRE ATT&CK vào các quy tắc tương quan |
| **Dùng chung 1 khóa Ingest API Key** | Biến môi trường `INGEST_API_KEY` được dùng chung cho cả Web, Cowrie, Suricata và ML forwarders | Nếu một cảm biến biên bị lộ khóa, kẻ tấn công có thể giả mạo dữ liệu cho các nguồn còn lại | Triển khai cơ chế cấp phát API Key riêng biệt cho từng trạm cảm biến kèm phân quyền nguồn dữ liệu |

---

## 4.8. Danh mục tài liệu và tệp minh chứng thực nghiệm

Toàn bộ dữ liệu thực nghiệm đã được đóng gói đầy đủ trong tệp lưu trữ [chapter4_evidence.zip](file:///d:/A/A_5chai/honey_pot/chapter4_evaluation/chapter4_evidence.zip). Cấu trúc các tệp thành phần bao gồm:

1.  **Báo cáo tổng hợp:** `chapter4_evaluation_report.md` (Tài liệu này)
2.  **Thông số thiết lập môi trường:** `experimental_setup.md`
3.  **Tệp dữ liệu bảng kết quả đo (CSV / JSON):**
    *   `ingestion_results.csv`: Kết quả kiểm thử nạp dữ liệu 4 nguồn.
    *   `dedup_test_results.csv`: Dữ liệu kiểm thử cơ chế loại trừ trùng lặp.
    *   `web_detection_results.csv`: Bảng ma trận phát hiện 10 nhóm tấn công Web.
    *   `signature_detection_results.csv`: Kết quả kích hoạt 10 chữ ký luật Suricata.
    *   `ml_metrics.json`: Toàn bộ chỉ số hiệu năng mô hình học máy trích xuất từ artifact.
    *   `ml_per_class_metrics.csv`: Bảng đo lường chi tiết 7 phân lớp của mô hình ML.
    *   `correlation_results.csv`: Dữ liệu kiểm thử 4 luật tương quan và các đối chứng âm.
    *   `performance_results.csv`: Tập dữ liệu 500 yêu cầu đo độ trễ Ingest API.
    *   `latency_summary.json`: Bảng tổng hợp độ trễ từng phân đoạn hệ thống.
    *   `isolation_test_results.csv`: Kết quả 10 bài kiểm thử an toàn và cách ly mạng.
    *   `limitations_and_improvements.csv`: Danh mục 14 hạn chế kỹ thuật và giải pháp.
4.  **Thư mục ảnh chụp minh chứng chất lượng cao (`screenshots/` - Đảm bảo quy tắc không chứa số chương/mục):**
    *   `runtime_services_status.png`: Trạng thái hoạt động thực tế của 23 containers.
    *   `ingestion_pipeline_results.png`: Bảng minh chứng tỷ lệ tiếp nhận dữ liệu 100%.
    *   `deduplication_replay_evidence.png`: Nhật ký chứng minh cơ chế Dedup và Forwarder Replay.
    *   `web_detection_matrix.png`: Bảng ma trận tỷ lệ phát hiện các lỗ hổng Web.
    *   `suricata_signatures_detection.png`: Bảng kiểm thử các chữ ký Suricata và mẫu lành tính.
    *   `ml_confusion_matrix.png`: Biểu đồ ma trận nhầm lẫn của mô hình XGBoost.
    *   `ml_per_class_metrics.png`: Biểu đồ trực quan hóa Precision, Recall và F1 từng lớp.
    *   `correlation_rules_matrix.png`: Bảng ma trận kết quả kích hoạt luật tương quan.
    *   `correlation_alert_postgres_evidence.png`: Bản ghi cảnh báo tương quan thực tế trong cơ sở dữ liệu PostgreSQL.
    *   `api_ingestion_latency_distribution.png`: Biểu đồ phân phối độ trễ tiếp nhận Ingest API.
    *   `latency_component_breakdown.png`: Biểu đồ phân rã độ trễ các thành phần hệ thống.
    *   `isolation_containment_matrix.png`: Bảng kiểm chứng an toàn và ngăn chặn độc hại.
    *   `upload_quarantine_storage.png`: Cấu trúc thư mục cách ly tệp độc hại thực tế.
    *   `dashboard_live_analytics.png`: Ảnh chụp thực tế giao diện giám sát SOC Dashboard.
5.  **Thư mục nhật ký thô (`raw/`):** Chứa toàn bộ logs thực thi nguyên bản của các bài kiểm thử tự động, kết quả truy vấn SQL và phản hồi API.
