# TÀI LIỆU RÀ SOÁT VÀ HIỆU CHỈNH THỰC NGHIỆM CHƯƠNG 4 (CORRECTIONS & AUDIT LOG)

Tài liệu này tổng hợp toàn bộ các điểm sai lệch, mâu thuẫn giữa bản nháp ban đầu và mã nguồn/môi trường thực thi (runtime) chuẩn xác của hệ thống, cùng chi tiết các hiệu chỉnh đã được áp dụng.

---

## 1. Hiệu chỉnh thông tin kiến trúc hệ thống

*   **Hệ thống xác thực và phân quyền (Auth Provider):**
    *   *Bản nháp cũ ghi:* Authelia MFA.
    *   *Xác minh thực tế (Authoritative Runtime):* Hệ thống sử dụng **Keycloak 26.x** kết hợp với cơ sở dữ liệu `keycloak-db` (PostgreSQL) và các cổng đảo chiều xác thực **oauth2-proxy** (`kibana-oauth2-proxy`, `prometheus-oauth2-proxy`). Cổng công khai của Keycloak là `8180/tcp` (ánh xạ vào cổng `8080` nội bộ).
    *   *Hiệu chỉnh:* Đã thay thế toàn bộ các đề cập về Authelia thành Keycloak + oauth2-proxy; cập nhật ảnh chụp tiến trình `runtime_services_status.png`.
*   **Cổng dịch vụ thực tế (Published Ports):**
    *   `lan-web-edge`: `0.0.0.0:8080->8080/tcp` (Web Honeypot truy cập từ mạng LAN).
    *   `edge`: `127.0.0.1:8088->8088/tcp` (Web Honeypot Public Lure) và `127.0.0.1:8090->8090/tcp` (Control API, Ingest API và Dashboard reverse proxy).
    *   `ssh-edge`: `127.0.0.1:2222->2222/tcp` (Cowrie SSH Honeypot).
    *   `keycloak`: `0.0.0.0:8180->8080/tcp` (Keycloak OIDC Identity Provider).
    *   `grafana`: `127.0.0.1:3000->3000/tcp` (Giao diện đo lường Prometheus/Metrics).
    *   `kibana-oauth2-proxy`: `127.0.0.1:5601->4180/tcp` (Giao diện Kibana SIEM qua Keycloak).
    *   `prometheus-oauth2-proxy`: `127.0.0.1:9090->4180/tcp` (Prometheus Metrics qua Keycloak).
    *   Các cổng cơ sở dữ liệu (`postgres: 5432`, `redis: 6379`, `elasticsearch: 9200`) **hoàn toàn không bind ra host** (`PortBindings: null`).
*   **Quy mô container:** Chính xác là **23 container** (21 container running/healthy và 2 container setup: `kibana-setup-1`, `keycloak-setup-1` đã hoàn tất tác vụ khởi tạo).
*   **7 phân vùng mạng Docker:**
    *   Mạng ngoại vi: `public` và `lan_ingress`.
    *   Mạng nội bộ cô lập (`internal: true`): `lure`, `control`, `data`, `siem`, `auth`.

---

## 2. Hiệu chỉnh dữ liệu mô hình học máy (Machine Learning)

*   **Tập dữ liệu huấn luyện:**
    *   *Bản nháp cũ ghi:* CIC-IDS2017 & CSE-CIC-IDS2018.
    *   *Xác minh thực tế (Authoritative Source):* Hồ sơ tạo tác chính thức `part_01_AI_ML/report/run_metadata.json` và `part_01_AI_ML/artifacts/manifest.json` ghi nhận tập dữ liệu duy nhất là **CICIoT2023**.
    *   *Hiệu chỉnh:* Xóa bỏ 100% các đề cập về CIC-IDS2017 và CSE-CIC-IDS2018.
*   **Danh sách 7 phân lớp tấn công (Class Names):**
    *   *Bản nháp cũ ghi:* Botnet, Infiltration, PortScan, DoS, DDoS, BruteForce, Benign.
    *   *Xác minh thực tế:* Danh mục 7 lớp chuẩn trong `manifest.json` và `metrics.json` là:
        1.  **Benign** (Lưu lượng sạch)
        2.  **BruteForce** (Dò quét mật khẩu)
        3.  **DDoS** (Từ chối dịch vụ phân tán)
        4.  **DoS** (Từ chối dịch vụ)
        5.  **Mirai** (Mã độc mạng vạn vật kết nối Mirai)
        6.  **Recon** (Rà quét trinh sát mạng)
        7.  **Spoofing** (Giả mạo địa chỉ IP / ARP)
    *   *Hiệu chỉnh:* Cập nhật bảng chỉ số phân lớp, biểu đồ ma trận nhầm lẫn (`ml_confusion_matrix.png`) và biểu đồ cột (`ml_per_class_metrics.png`) đúng chuẩn 7 lớp trên.
*   **Quy mô mẫu và số tệp dữ liệu:**
    *   Tổng số tệp: 169 tệp (135 tệp huấn luyện, 34 tệp kiểm thử độc lập).
    *   Số dòng luồng thô đã thấy trong tập train: **37,101,078 dòng**.
    *   Số mẫu train sau lấy mẫu cân bằng (reservoir sampling): **610,328 mẫu**.
    *   Số mẫu kiểm thử độc lập: **9,560,672 mẫu**.

---

## 3. Hiệu chỉnh ánh xạ chữ ký luật Suricata (SIDs 9900001–9900010)

*   *Bản nháp cũ ghi sai nội dung một số SID:* Ghi SID 9900004 là `/etc/passwd`, 9900005 là command injection, 9900006 là webshell, 9900010 là scanner.
*   *Xác minh trực tiếp từ tệp luật hiện tại:* `part_05_IDS_ML_DETECTION/config/suricata/honeypot.rules` và bộ chuẩn hóa `part_05_IDS_ML_DETECTION/ids_bridge/normalizers.py`:
    *   **SID 9900001:** `sql_injection` — HONEYPOT possible SQL injection
    *   **SID 9900002:** `reflected_xss` — HONEYPOT reflected XSS payload
    *   **SID 9900003:** `path_traversal` — HONEYPOT path traversal
    *   **SID 9900004:** `command_injection` — HONEYPOT command injection
    *   **SID 9900005:** `xxe` — HONEYPOT XXE payload
    *   **SID 9900006:** `remote_file_inclusion` — HONEYPOT remote include attempt
    *   **SID 9900007:** `unrestricted_file_upload` — HONEYPOT executable upload name
    *   **SID 9900008:** `brute_force` — HONEYPOT repeated login requests
    *   **SID 9900009:** `idor` — HONEYPOT restricted record IDOR
    *   **SID 9900010:** `stored_xss` — HONEYPOT stored XSS submission
*   *Hiệu chỉnh:* Đã đồng bộ lại bảng dữ liệu, báo cáo chi tiết và ảnh minh chứng `suricata_signatures_detection.png`.

---

## 4. Hiệu chỉnh cơ chế lưu trữ và độ trễ tương quan (SIEM Correlation)

*   **Bảng đích lưu trữ cảnh báo tương quan:**
    *   *Bản nháp cũ ghi:* Bảng `correlation_alerts`.
    *   *Xác minh thực tế trong PostgreSQL:* Cơ sở dữ liệu `honeypot` chỉ có duy nhất một bảng `events`. Tiến trình `siem/run.py` chuyển đổi alert thành event qua hàm `to_part3_event()` và gửi POST tới `/api/v1/events` với `sensor_id = "siem-correlation-01"`. Cảnh báo tương quan được lưu trực tiếp vào bảng `events` với:
        *   `event_type`: `"alert"`
        *   `method`: `"CORRELATE"`
        *   `path`: `"siem://correlation"`
        *   `vulnerability`: Mã quy tắc tương quan (`rule_id`)
        *   `request_metadata`: Chứa `title` và danh sách mảng `evidence_ids`.
    *   *Hiệu chỉnh:* Đã sửa toàn bộ câu lệnh truy vấn, tài liệu báo cáo và chụp lại ảnh bằng chứng PostgreSQL `correlation_alert_postgres_evidence.png` trích xuất trực tiếp từ bảng `events`.
*   **Phân định rạch ròi giữa thời gian hàm tương quan và độ trễ dịch vụ:**
    *   *Hàm tương quan nội tại (`correlation_function_latency`):* Đo lường trực tiếp thời gian gọi hàm `correlate(events, rules)` bằng `time.perf_counter()` đạt trung bình **0.038s – 0.058s** `[RUNTIME MEASURED]`.
    *   *Độ trễ kích hoạt dịch vụ thực tế (`correlation_service_delay`):* Do tiến trình `siem/run.py` ngủ cứng 30 giây trong vòng lặp nền (`time.sleep(30)`), độ trễ từ khi sự kiện cuối cùng được lưu vào cơ sở dữ liệu đến khi dịch vụ thức dậy và sinh cảnh báo dao động từ 0 đến 30 giây (kỳ vọng trung bình 15.0s). Phép đo độ trễ tức thời trong lab trước đây không phản ánh độ trễ chu kỳ này, do đó ghi nhận chính thức là **[NOT MEASURED]** (được chi phối bởi cấu hình chu kỳ 30s `[CONFIG DERIVED]`).

---

## 5. Hiệu chỉnh phạm vi đánh giá Ingestion (Thu thập nhật ký)

*   *Vấn đề:* Script `eval_ingestion_and_dedup.py` tạo các mẫu sự kiện nhân tạo (synthetic events) mô phỏng cấu trúc của 4 nguồn rồi POST trực tiếp vào Ingest API.
*   *Xác minh tính chất thực nghiệm:* Phép đo trên kiểm chứng khả năng tiếp nhận, xác thực schema và ghi nhận của **Ingest API đối với các định dạng dữ liệu từ 4 nguồn** (đạt 100%), chứ **chưa phải là kiểm thử toàn trình từ đầu đến cuối (End-to-End Pipeline Validation)** của 3 nguồn Cowrie, Suricata và ML Sensor.
*   *Hiệu chỉnh:*
    *   Đổi tên bảng đánh giá thành: **"API Ingestion by Source-Shaped Payloads"**.
    *   Ghi rõ trạng thái kiểm thử toàn trình:
        *   Web Pipeline: Đạt **[RUNTIME VERIFIED]** nhờ thực nghiệm Replay khi khởi động lại forwarder (276 sự kiện đọc từ SQLite cục bộ -> Ingest API -> PostgreSQL).
        *   Cowrie Pipeline: Đánh giá qua API shaped events; kiểm thử toàn trình ghi nhận **[NOT VERIFIED END-TO-END]**.
        *   Suricata Pipeline: Đánh giá qua API shaped events; kiểm thử toàn trình ghi nhận **[NOT VERIFIED END-TO-END]**.
        *   ML Sensor Pipeline: Đánh giá qua API shaped events; kiểm thử toàn trình ghi nhận **[NOT VERIFIED END-TO-END]**.

---

## 6. Hiệu chỉnh nhãn nguồn gốc số liệu độ trễ (Latency Provenance)

Toàn bộ các chỉ số độ trễ được phân loại minh bạch theo 4 nhóm nhãn:
1.  **[RUNTIME MEASURED]:**
    *   Độ trễ tiếp nhận Ingest API (500 yêu cầu): Mean = 24.67 ms, Median = 22.16 ms, P95 = 38.16 ms.
    *   Thông lượng nạp theo lô (Batch Throughput): 156.31 sự kiện/giây.
    *   Độ trễ suy luận XGBoost: Chế độ lô = 0.00919 ms/dòng; Chế độ đơn vị = 2.99 ms/luồng.
    *   Thời gian thực thi hàm tương quan Python `correlate()`: 0.038s – 0.058s.
2.  **[SOURCE VERIFIED]:**
    *   Thông số tập dữ liệu CICIoT2023, 46 đặc trưng, 7 phân lớp, các chỉ số Accuracy (99.64%), Weighted F1 (99.64%), BruteForce F1 (69.44%).
    *   Cấu trúc bảng `events`, mã định danh sensor `siem-correlation-01`.
3.  **[CONFIG DERIVED]:**
    *   Khoảng thời gian thăm dò của Forwarder: 2.0 giây (`POLL_INTERVAL = 2.0`).
    *   Thời gian chờ đóng luồng mạng (Flow Timeout): `idle_timeout = 5.0s`, `active_timeout = 30.0s`.
    *   Chu kỳ quét tương quan SIEM: Vòng lặp ngủ 30.0 giây (`sleep(30)`).
    *   Chu kỳ kéo dữ liệu Dashboard: Polling 3.0 giây trên React Frontend.
    *   Thời gian sống đệm Redis (Cache TTL): 30.0 giây cho các chỉ số tổng hợp.
4.  **[NOT MEASURED]:**
    *   Thời gian từ Web Request đến khi commit SQLite cục bộ (dưới mili-giây, chưa gắn đồng hồ đo phân giải cao).
    *   Độ trễ dịch vụ tương quan thực tế từ triggering event đến cảnh báo (`correlation_service_delay`).
    *   Độ trễ hiển thị tự động trên trình duyệt từ khi tiêm tấn công (`end_to_end_attack_to_dashboard`).

---

## 7. Loại bỏ các phát biểu phóng đại (Overclaims)

Đã loại bỏ hoàn toàn các từ ngữ mang tính khẳng định tuyệt đối và thay thế bằng mô tả kỹ thuật chuẩn xác theo phạm vi kiểm thử:
*   *Bỏ:* "zero data loss tuyệt đối" -> *Thay bằng:* "Hệ thống bảo toàn các sự kiện trong hàng đợi SQLite cục bộ khi forwarder khởi động lại và cơ chế dedup tại cơ sở dữ liệu ngăn chặn nhân bản bản ghi".
*   *Bỏ:* "triệt để", "hoàn hảo", "bù đắp hoàn hảo" -> *Thay bằng:* "hạn chế được tỷ lệ âm tính giả", "hoạt động hiệu quả theo đúng điều kiện kiểm thử".
*   *Bỏ:* "không thể escape container" -> *Thay bằng:* "Các bài kiểm thử tiêm lệnh OS, đọc tệp và tải mã độc không phát sinh tiến trình hay kết nối mạng độc hại ngoài phạm vi cô lập của container".
*   *Bỏ:* "Zero Trust" -> *Thay bằng:* "Mô hình phân vùng mạng nghiêm ngặt (Network Segmentation) với 5 mạng nội bộ cô lập".
